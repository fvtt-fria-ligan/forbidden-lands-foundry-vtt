class ForbiddenLandsActor extends Actor {
	createEmbeddedEntity(embeddedName, data, options) {
		// Replace randomized attributes like "[[d6]] days" with a roll
		let newData = duplicate(data);
		const inlineRoll = /\[\[(\/[a-zA-Z]+\s)?([^\]]+)\]\]/gi;
		if (newData.data) {
			for (let key of Object.keys(newData.data)) {
				if (typeof newData.data[key] === "string") {
					newData.data[key] = newData.data[key].replace(
						inlineRoll,
						(_match, _contents, formula) => new Roll(formula).roll().total,
					);
				}
			}
		}
		return super.createEmbeddedEntity(embeddedName, newData, options);
	}
}

class ForbiddenLandsItem extends Item {
	async sendToChat() {
		const itemData = duplicate(this.data);
		if (itemData.img.includes("/mystery-man")) {
			itemData.img = null;
		}
		if (game.fbl.config.itemTypes.includes(itemData.type)) itemData[`is${itemData.type.capitalize()}`] = true;
		itemData.hasRollModifiers =
			itemData.data.rollModifiers && Object.values(itemData.data.rollModifiers).length > 0;
		const html = await renderTemplate("systems/forbidden-lands/templates/chat/item.hbs", itemData);
		const chatData = {
			user: game.user._id,
			rollMode: game.settings.get("core", "rollMode"),
			content: html,
			["flags.forbidden-lands.itemData"]: this.data, // Adds posted item data to chat message flags for item drag/drop
		};
		if (["gmroll", "blindroll"].includes(chatData.rollMode)) {
			chatData.whisper = ChatMessage.getWhisperRecipients("GM");
		} else if (chatData.rollMode === "selfroll") {
			chatData.whisper = [game.user];
		}
		ChatMessage.create(chatData);
	}
}

function initializeCalendar() {
	// Init support for the Calendar/Weather module
	if (!game.modules.get("calendar-weather")?.active) {
		console.warn(
			"Install the Calendar/Weather module for calendar support: https://foundryvtt.com/packages/calendar-weather/",
		);
		return;
	}

	let calendarData = game.settings.get("calendar-weather", "dateTime");
	if (!calendarData) {
		calendarData = {};
	}

	if (!calendarData.default) {
		calendarData.default = {
			currentMonth: 2,
			day: 1,
			dayLength: 24,
			daysOfTheWeek: ["Sunday", "Moonday", "Bloodday", "Earthday", "Growthday", "Feastday", "Stillday"],
			era: "AS",
			events: [],
			months: [
				{ isNumbered: true, length: 46, name: "Winterwane" },
				{ isNumbered: true, length: 45, name: "Springrise" },
				{ isNumbered: true, length: 46, name: "Springwane" },
				{ isNumbered: true, length: 45, name: "Sumerrise" },
				{ isNumbered: true, length: 46, name: "Summerwane" },
				{ isNumbered: true, length: 45, name: "Fallrise" },
				{ isNumbered: true, length: 46, name: "Fallwane" },
				{ isNumbered: true, length: 45, name: "Winterrise" },
			],
			moons: [
				{
					cycleLength: 30,
					cyclePercent: 70,
					isWaxing: false,
					name: "Moon",
					solarEclipseChance: 0.0005,
					lunarEclipseChance: 0.02,
				},
			],
			reEvents: [
				{ name: "Midwinter", date: { combined: "1-1", day: 1, month: "1" }, text: "" },
				{ name: "Awakening Day", date: { combined: "2-1", day: 1, month: "2" }, text: "" },
				{ name: "Springturn", date: { combined: "3-1", day: 1, month: "3" }, text: "" },
				{ name: "Lushday", date: { combined: "4-1", day: 1, month: "4" }, text: "" },
				{ name: "Midsummer", date: { combined: "5-1", day: 1, month: "5" }, text: "" },
				{ name: "Harvest Day", date: { combined: "6-1", day: 1, month: "6" }, text: "" },
				{ name: "Fallturn", date: { combined: "7-1", day: 1, month: "7" }, text: "" },
				{ name: "Rotday", date: { combined: "8-1", day: 1, month: "8" }, text: "" },
			],
			seasons: [
				{
					color: "green",
					date: { combined: "2-1", day: 1, month: "2" },
					dawn: 3,
					dusk: 15,
					humidity: "=",
					name: "Spring",
					rolltable: "",
					temp: "=",
				},
				{
					color: "red",
					date: { combined: "4-1", day: 1, month: "4" },
					dawn: 3,
					dusk: 21,
					humidity: "+",
					name: "Summer",
					rolltable: "",
					temp: "+",
				},
				{
					color: "orange",
					date: { combined: "6-1", day: 1, month: "6" },
					dawn: 3,
					dusk: 15,
					humidity: "=",
					name: "Fall",
					rolltable: "",
					temp: "=",
				},
				{
					color: "blue",
					date: { combined: "8-1", day: 1, month: "8" },
					dawn: 9,
					dusk: 15,
					humidity: "-",
					name: "Winter",
				},
			],
			weather: {
				climate: "temperate",
				climateHumidity: 0,
				climateTemp: 0,
				cTemp: 21.11,
				dawn: 5,
				dusk: 19,
				doNightCycle: false,
				humidity: 0,
				isC: true,
				isVolcanic: false,
				lastTemp: 70,
				outputToChat: true,
				precipitation: "",
				season: "Spring",
				seasonColor: "green",
				seasonHumidity: 0,
				seasonRolltable: "",
				seasonTemp: 0,
				showFX: false,
				temp: 53,
				weatherFX: [],
			},
			year: 1165,
		};
		game.settings.set("calendar-weather", "dateTime", calendarData);
	}
}

class ForbiddenLandsD6 extends Die {
	constructor(termData) {
		termData.faces = 6;
		super(termData);
	}

	static DENOMINATION = 6;

	static getResultLabel(result) {
		return `<img src="systems/forbidden-lands/assets/dice/skill-d6-${result}.png" alt="${result}" title="${result}" />`;
	}
}

class BaseDie extends ForbiddenLandsD6 {
	static DENOMINATION = "b";

	static getResultLabel(result) {
		return `<img src="systems/forbidden-lands/assets/dice/base-d6-${result}.png" alt="${result}" title="${result}" />`;
	}
}

class GearDie extends ForbiddenLandsD6 {
	static DENOMINATION = "g";

	static getResultLabel(result) {
		return `<img src="systems/forbidden-lands/assets/dice/gear-d6-${result}.png" alt="${result}" title="${result}" />`;
	}
}

class SkillDie extends ForbiddenLandsD6 {
	static DENOMINATION = "s";
}

class ArtifactD8 extends Die {
	constructor(termData) {
		termData.faces = 8;
		super(termData);
	}

	static DENOMINATION = 8;

	static getResultLabel(result) {
		return `<img src="systems/forbidden-lands/assets/dice/artifact-d8-${result}.png" alt="${result}" title="${result}" />`;
	}
}

class ArtifactD10 extends Die {
	constructor(termData) {
		termData.faces = 10;
		super(termData);
	}

	static DENOMINATION = 10;

	static getResultLabel(result) {
		return `<img src="systems/forbidden-lands/assets/dice/artifact-d10-${result}.png" alt="${result}" title="${result}" />`;
	}
}

class ArtifactD12 extends Die {
	constructor(termData) {
		termData.faces = 12;
		super(termData);
	}

	static DENOMINATION = 12;

	static getResultLabel(result) {
		return `<img src="systems/forbidden-lands/assets/dice/artifact-d12-${result}.png" alt="${result}" title="${result}" />`;
	}
}

function registerDice() {
	CONFIG.Dice.terms.b = BaseDie;
	CONFIG.Dice.terms.g = GearDie;
	CONFIG.Dice.terms.s = SkillDie;
	CONFIG.Dice.terms["6"] = ForbiddenLandsD6;
	CONFIG.Dice.terms["8"] = ArtifactD8;
	CONFIG.Dice.terms["10"] = ArtifactD10;
	CONFIG.Dice.terms["12"] = ArtifactD12;
}

function registerDiceSoNice(dice3d) {
	dice3d.addSystem({ id: "forbidden-lands", name: "Forbidden Lands" }, true);
	dice3d.addColorset({
		name: "fl-base",
		category: "Forbidden Lands",
		description: "Base Dice",
		background: "#ffffff",
		edge: "#ffffff",
		material: "plastic",
	});
	dice3d.addColorset({
		name: "fl-gear",
		category: "Forbidden Lands",
		description: "Gear Dice",
		background: "#000000",
		edge: "#000000",
		material: "plastic",
	});
	dice3d.addColorset({
		name: "fl-skill",
		category: "Forbidden Lands",
		description: "Skill Dice",
		background: "#9d1920",
		edge: "#9d1920",
		material: "plastic",
	});
	dice3d.addColorset({
		name: "fl-d8",
		category: "Forbidden Lands",
		description: "D8",
		background: "#4f6d47",
		edge: "#4f6d47",
		material: "plastic",
	});
	dice3d.addColorset({
		name: "fl-d10",
		category: "Forbidden Lands",
		description: "D10",
		background: "#329bd6",
		edge: "#329bd6",
		material: "plastic",
	});
	dice3d.addColorset({
		name: "fl-d12",
		category: "Forbidden Lands",
		description: "D12",
		background: "#f15700",
		edge: "#f15700",
		material: "plastic",
	});
	dice3d.addDicePreset(
		{
			type: "db",
			labels: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-black.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-black.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-black.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-black.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-black.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-black.png",
			],
			bumpMaps: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-bump.png",
			],
			colorset: "fl-base",
			system: "forbidden-lands",
		},
		"d6",
	);
	dice3d.addDicePreset(
		{
			type: "dg",
			labels: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-white.png",
			],
			bumpMaps: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-bump.png",
			],
			colorset: "fl-gear",
			system: "forbidden-lands",
		},
		"d6",
	);
	dice3d.addDicePreset(
		{
			type: "ds",
			labels: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-skill-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-white.png",
			],
			bumpMaps: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-skill-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-bump.png",
			],
			colorset: "fl-skill",
			system: "forbidden-lands",
		},
		"d6",
	);
	dice3d.addDicePreset(
		{
			type: "d6",
			labels: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-skill-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-white.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-white.png",
			],
			bumpMaps: [
				"systems/forbidden-lands/assets/dsn/d6/d6-1-skill-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-2-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-3-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-4-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-5-bump.png",
				"systems/forbidden-lands/assets/dsn/d6/d6-6-bump.png",
			],
			colorset: "fl-skill",
			system: "forbidden-lands",
		},
		"d6",
	);
	dice3d.addDicePreset(
		{
			type: "d8",
			labels: [
				"systems/forbidden-lands/assets/dsn/d8/d8-1.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-2.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-3.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-4.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-5.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-6.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-7.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-8.png",
			],
			bumpMaps: [
				"systems/forbidden-lands/assets/dsn/d8/d8-1-bump.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-2-bump.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-3-bump.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-4-bump.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-5-bump.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-6-bump.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-7-bump.png",
				"systems/forbidden-lands/assets/dsn/d8/d8-8-bump.png",
			],
			colorset: "fl-d8",
			system: "forbidden-lands",
		},
		"d8",
	);
	dice3d.addDicePreset(
		{
			type: "d10",
			labels: [
				"systems/forbidden-lands/assets/dsn/d10/d10-1.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-2.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-3.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-4.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-5.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-6.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-7.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-8.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-9.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-10.png",
			],
			bumpMaps: [
				"systems/forbidden-lands/assets/dsn/d10/d10-1-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-2-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-3-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-4-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-5-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-6-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-7-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-8-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-9-bump.png",
				"systems/forbidden-lands/assets/dsn/d10/d10-10-bump.png",
			],
			colorset: "fl-d10",
			system: "forbidden-lands",
		},
		"d10",
	);
	dice3d.addDicePreset(
		{
			type: "d12",
			labels: [
				"systems/forbidden-lands/assets/dsn/d12/d12-1.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-2.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-3.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-4.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-5.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-6.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-7.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-8.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-9.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-10.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-11.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-12.png",
			],
			bumpMaps: [
				"systems/forbidden-lands/assets/dsn/d12/d12-1-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-2-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-3-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-4-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-5-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-6-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-7-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-8-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-9-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-10-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-11-bump.png",
				"systems/forbidden-lands/assets/dsn/d12/d12-12-bump.png",
			],
			colorset: "fl-d12",
			system: "forbidden-lands",
		},
		"d12",
	);
}

function registerFonts() {
	CONFIG.fontFamilies.push("IM Fell Great Primer");
	CONFIG.fontFamilies.push("IM Fell DW Pica");
	CONFIG.fontFamilies.push("IM Fell DW Pica SC");
	CONFIG.fontFamilies.push("Poppins");
	CONFIG.defaultFontFamily = "IM Fell DW Pica";
}

function preloadHandlebarsTemplates() {
	const templatePaths = [
		"systems/forbidden-lands/templates/chat/item.hbs",
		"systems/forbidden-lands/templates/chat/roll.hbs",
		"systems/forbidden-lands/templates/chat/consumable.hbs",
		"systems/forbidden-lands/templates/character.hbs",
		"systems/forbidden-lands/templates/monster.hbs",
		"systems/forbidden-lands/templates/weapon.hbs",
		"systems/forbidden-lands/templates/armor.hbs",
		"systems/forbidden-lands/templates/monster-talent.hbs",
		"systems/forbidden-lands/templates/monster-attack.hbs",
		"systems/forbidden-lands/templates/gear.hbs",
		"systems/forbidden-lands/templates/raw-material.hbs",
		"systems/forbidden-lands/templates/talent.hbs",
		"systems/forbidden-lands/templates/critical-injury.hbs",
		"systems/forbidden-lands/templates/tab/main.hbs",
		"systems/forbidden-lands/templates/tab/combat.hbs",
		"systems/forbidden-lands/templates/tab/combat-monster.hbs",
		"systems/forbidden-lands/templates/tab/talent.hbs",
		"systems/forbidden-lands/templates/tab/gear-character.hbs",
		"systems/forbidden-lands/templates/tab/gear-monster.hbs",
		"systems/forbidden-lands/templates/tab/bio.hbs",
		"systems/forbidden-lands/templates/tab/building-stronghold.hbs",
		"systems/forbidden-lands/templates/tab/hireling-stronghold.hbs",
		"systems/forbidden-lands/templates/tab/gear-stronghold.hbs",
		"systems/forbidden-lands/templates/partial/roll-modifiers.hbs",
		"systems/forbidden-lands/templates/tab/gear/gear-artifact.hbs",
		"systems/forbidden-lands/templates/tab/gear/gear-supply.hbs",
		"systems/forbidden-lands/templates/tab/gear/armor-main.hbs",
		"systems/forbidden-lands/templates/tab/gear/gear-main.hbs",
		"systems/forbidden-lands/templates/tab/gear/weapon-main.hbs",
		"systems/forbidden-lands/templates/tab/party-main.hbs",
		"systems/forbidden-lands/templates/tab/travel.hbs",
		"systems/forbidden-lands/templates/partial/travel-action.hbs",
		"systems/forbidden-lands/templates/partial/party-member.hbs",
		"systems/forbidden-lands/templates/party.hbs",
		"systems/forbidden-lands/templates/partial/list.hbs",
	];
	return loadTemplates(templatePaths);
}

function registerHandlebarsHelpers() {
	Handlebars.registerHelper("skulls", function (current, max, block) {
		var acc = "";
		for (var i = 0; i < max; ++i) {
			block.data.index = i;
			block.data.damaged = i >= current;
			acc += block.fn(this);
		}
		return acc;
	});
	Handlebars.registerHelper("flps_enrich", function (content) {
		// Enrich the content
		content = TextEditor.enrichHTML(content, { entities: true });
		return new Handlebars.SafeString(content);
	});
	Handlebars.registerHelper("flps_capitalize", function (value) {
		return typeof value === "string" && value.length > 0 ? value[0].toUpperCase() + value.slice(1) : value;
	});
	Handlebars.registerHelper("flps_strconcat", function () {
		const args = Array.prototype.slice.call(arguments);
		args.pop(); // remove unrelated data
		return args.join("");
	});

	Handlebars.registerHelper("flps_enrich", function (content) {
		// Enrich the content
		content = TextEditor.enrichHTML(content, { entities: true });
		return new Handlebars.SafeString(content);
	});

	Handlebars.registerHelper("damageType", function (type) {
		type = normalize(type, "blunt");
		switch (type) {
			case "blunt":
				return game.i18n.localize("ATTACK.BLUNT");
			case "fear":
				return game.i18n.localize("ATTACK.FEAR");
			case "slash":
				return game.i18n.localize("ATTACK.SLASH");
			case "stab":
				return game.i18n.localize("ATTACK.STAB");
			case "other":
				return game.i18n.localize("ATTACK.OTHER");
		}
	});
	Handlebars.registerHelper("armorPart", function (part) {
		part = normalize(part, "body");
		switch (part) {
			case "body":
				return game.i18n.localize("ARMOR.BODY");
			case "head":
				return game.i18n.localize("ARMOR.HELMET");
			case "shield":
				return game.i18n.localize("ARMOR.SHIELD");
		}
	});
	Handlebars.registerHelper("itemWeight", function (weight) {
		weight = normalize(weight, "regular");
		switch (weight) {
			case "none":
				return game.i18n.localize("WEIGHT.NONE");
			case "tiny":
				return game.i18n.localize("WEIGHT.TINY");
			case "light":
				return game.i18n.localize("WEIGHT.LIGHT");
			case "regular":
				return game.i18n.localize("WEIGHT.REGULAR");
			case "heavy":
				return game.i18n.localize("WEIGHT.HEAVY");
			default:
				return weight;
		}
	});
	Handlebars.registerHelper("weaponCategory", function (category) {
		category = normalize(category, "melee");
		switch (category) {
			case "melee":
				return game.i18n.localize("WEAPON.MELEE");
			case "ranged":
				return game.i18n.localize("WEAPON.RANGED");
		}
	});
	Handlebars.registerHelper("weaponGrip", function (grip) {
		grip = normalize(grip, "1h");
		switch (grip) {
			case "1h":
				return game.i18n.localize("WEAPON.1H");
			case "2h":
				return game.i18n.localize("WEAPON.2H");
		}
	});
	Handlebars.registerHelper("weaponRange", function (range) {
		range = normalize(range, "arm");
		switch (range) {
			case "arm":
				return game.i18n.localize("RANGE.ARM");
			case "near":
				return game.i18n.localize("RANGE.NEAR");
			case "short":
				return game.i18n.localize("RANGE.SHORT");
			case "long":
				return game.i18n.localize("RANGE.LONG");
			case "distant":
				return game.i18n.localize("RANGE.DISTANT");
		}
	});
	Handlebars.registerHelper("talentType", function (type) {
		type = normalize(type, "general");
		switch (type) {
			case "general":
				return game.i18n.localize("TALENT.GENERAL");
			case "kin":
				return game.i18n.localize("TALENT.KIN");
			case "profession":
				return game.i18n.localize("TALENT.PROFESSION");
		}
	});
	Handlebars.registerHelper("isBroken", function (item) {
		if (parseInt(item.data.bonus.max, 10) > 0 && parseInt(item.data.bonus.value, 10) === 0) {
			return "broken";
		} else {
			return "";
		}
	});
	Handlebars.registerHelper("formatRollModifiers", function (rollModifiers) {
		let output = [];
		Object.values(rollModifiers).forEach((mod) => {
			let name = game.i18n.localize(mod.name);
			output.push(`${name} ${mod.value}`);
		});
		return output.join(", ");
	});

	Handlebars.registerHelper("hasWeaponFeatures", function (weaponType, features) {
		const meleeFeatures = ["edged", "pointed", "blunt", "parry", "hook"];
		const rangedFeatures = ["slowReload"];

		if (features.others !== "") {
			return true;
		}

		let weaponFeatures = [];
		if (weaponType === "melee") {
			weaponFeatures = meleeFeatures;
		} else if (weaponType === "ranged") {
			weaponFeatures = rangedFeatures;
		}

		for (const feature in features) {
			if (weaponFeatures.includes(feature) && features[feature]) {
				return true;
			}
		}
		return false;
	});

	Handlebars.registerHelper("formatWeaponFeatures", function (weaponType, features) {
		let output = [];
		if (weaponType === "melee") {
			if (features.edged) {
				output.push(game.i18n.localize("WEAPON.FEATURES.EDGED"));
			}
			if (features.pointed) {
				output.push(game.i18n.localize("WEAPON.FEATURES.POINTED"));
			}
			if (features.blunt) {
				output.push(game.i18n.localize("WEAPON.FEATURES.BLUNT"));
			}
			if (features.parrying) {
				output.push(game.i18n.localize("WEAPON.FEATURES.PARRYING"));
			}
			if (features.hook) {
				output.push(game.i18n.localize("WEAPON.FEATURES.HOOK"));
			}
		}
		if (weaponType === "ranged") {
			if (features.slowReload) {
				output.push(game.i18n.localize("WEAPON.FEATURES.SLOW_RELOAD"));
			}
		}
		if (features.others !== "") {
			output.push(features.others);
		}
		return output.join(", ");
	});

	Handlebars.registerHelper("plaintextToHTML", function (value) {
		// strip tags, add <br/> tags
		return new Handlebars.SafeString(value.replace(/(<([^>]+)>)/gi, "").replace(/(?:\r\n|\r|\n)/g, "<br/>"));
	});
	Handlebars.registerHelper("toUpperCase", function (str) {
		return str.toUpperCase();
	});
	Handlebars.registerHelper("eq", function () {
		const args = Array.prototype.slice.call(arguments, 0, -1);
		return args.every(function (expression) {
			return args[0] === expression;
		});
	});
	Handlebars.registerHelper("or", function () {
		const args = Array.prototype.slice.call(arguments, 0, -1);
		return args.reduce((x, y) => x || y);
	});
	Handlebars.registerHelper("isMonsterTypeMount", function (type) {
		return type === "mount";
	});
}

function normalize(data, defaultValue) {
	if (data) {
		return data.toLowerCase();
	} else {
		return defaultValue;
	}
}

const initializeHandlebars = () => {
	registerHandlebarsHelpers();
	preloadHandlebarsTemplates();
};

const migrateWorld = async () => {
	const schemaVersion = 5;
	const systemVersion = Number(
		game.system.data.version.split(".")[0], //Get the first whole integer in system version.
	);
	const trueWorldSchemaVersion = Number(game.settings.get("forbidden-lands", "worldSchemaVersion") || 0); //Moved to a separate variable due to this being an exposed setting that can be set to integer, float or string. This also sets 0 if it evaluates to NaN.
	const worldSchemaVersion = trueWorldSchemaVersion <= systemVersion ? trueWorldSchemaVersion : systemVersion; //Intention here is to prevent worldSchema from being larger than systemversion preventing a migration and potentially "corrupting" the World.
	if (worldSchemaVersion !== schemaVersion && game.user.isGM) {
		ui.notifications.info("Upgrading the world, please wait...");
		for (let actor of game.actors.entities) {
			try {
				const update = migrateActorData(actor.data, worldSchemaVersion);
				if (!isObjectEmpty(update)) {
					await actor.update(update, { enforceTypes: false });
				}
			} catch (e) {
				console.error(e);
			}
		}
		for (let item of game.items.entities) {
			try {
				const update = migrateItemData(item.data, worldSchemaVersion);
				if (!isObjectEmpty(update)) {
					await item.update(update, { enforceTypes: false });
				}
			} catch (e) {
				console.error(e);
			}
		}
		for (let scene of game.scenes.entities) {
			try {
				const update = migrateSceneData(scene.data, worldSchemaVersion);
				if (!isObjectEmpty(update)) {
					await scene.update(update, { enforceTypes: false });
				}
			} catch (err) {
				console.error(err);
			}
		}
		for (let pack of game.packs.filter(
			(p) => p.metadata.package === "world" && ["Actor", "Item", "Scene"].includes(p.metadata.entity),
		)) {
			await migrateCompendium(pack, worldSchemaVersion);
		}
		migrateSettings(worldSchemaVersion);
		game.settings.set("forbidden-lands", "worldSchemaVersion", schemaVersion);
		ui.notifications.info("Upgrade complete!");
	}
};

const migrateActorData = (actor, worldSchemaVersion) => {
	const update = {};
	if (worldSchemaVersion <= 2) {
		if (actor.type === "character") {
			if (!actor.data.condition.sleepy) {
				update["data.condition.sleepy"] = actor.data.condition.sleepless;
			}
		}
	}
	let itemsChanged = false;
	const items = actor.items.map((item) => {
		const itemUpdate = migrateItemData(item, worldSchemaVersion);
		if (!isObjectEmpty(itemUpdate)) {
			itemsChanged = true;
			return mergeObject(item, itemUpdate, {
				enforceTypes: false,
				inplace: false,
			});
		}
		return item;
	});
	if (itemsChanged) {
		update.items = items;
	}
	return update;
};

const migrateItemData = (item, worldSchemaVersion) => {
	const update = {};
	if (worldSchemaVersion <= 2) {
		if (item.type === "artifact") {
			update.type = "weapon";
		}
		if (item.type === "armor") {
			update["data.bonus"] = item.data.rating;
		} else {
			let baseBonus = 0;
			let artifactBonus = "";
			if (item.data.bonus) {
				const parts = item.data.bonus.split("+").map((p) => p.trim());
				parts.forEach((p) => {
					if (Number.isNumeric(p)) {
						baseBonus += +p;
					} else {
						if (artifactBonus.length) {
							artifactBonus = `${artifactBonus} + ${p}`;
						} else {
							artifactBonus = p;
						}
					}
				});
			}
			update["data.bonus"] = {
				value: baseBonus,
				max: baseBonus,
			};
			update["data.artifactBonus"] = artifactBonus;
		}
	}
	if (worldSchemaVersion <= 3) {
		if (item.type === "spell" && !item.data.spellType) {
			update["data.spellType"] = "SPELL.SPELL";
		}
	}
	if (worldSchemaVersion <= 4) {
		if (item.type === "weapon" && typeof item.data.features === "string") {
			// Change features from string to object
			const features = item.data.features
				.replace(".", "")
				.replace(/loading is a slow action/i, "slowReload")
				.replace(/slow reload/i, "slowReload")
				.split(", ");
			update["data.features"] = {
				edged: false,
				pointed: false,
				blunt: false,
				parrying: false,
				hook: false,
				slowReload: false,
				others: "",
			};
			let otherFeatures = "";
			for (const feature of features) {
				const lcFeature = feature === "slowReload" ? feature : feature.toLowerCase();
				if (lcFeature in update["data.features"]) {
					update["data.features"][lcFeature] = true;
				} else {
					otherFeatures += feature + ", ";
				}
			}
			update["data.features"].others = otherFeatures.substr(0, otherFeatures.length - 2);
		}
	}
	if (!isObjectEmpty(update)) {
		update._id = item._id;
	}
	return update;
};

const migrateSceneData = (scene, worldSchemaVersion) => {
	const tokens = duplicate(scene.tokens);
	return {
		tokens: tokens.map((tokenData) => {
			if (!tokenData.actorId || tokenData.actorLink || !tokenData.actorData.data) {
				tokenData.actorData = {};
				return tokenData;
			}
			const token = new Token(tokenData);
			if (!token.actor) {
				tokenData.actorId = null;
				tokenData.actorData = {};
			} else if (!tokenData.actorLink && token.data.actorData.items) {
				const update = migrateActorData(token.data.actorData, worldSchemaVersion);
				console.log("ACTOR CHANGED", token.data.actorData, update);
				tokenData.actorData = mergeObject(token.data.actorData, update);
			}
			return tokenData;
		}),
	};
};

const migrateCompendium = async function (pack, worldSchemaVersion) {
	const entity = pack.metadata.entity;

	await pack.migrate();
	const content = await pack.getContent();

	for (let ent of content) {
		let updateData = {};
		if (entity === "Item") {
			updateData = migrateItemData(ent.data, worldSchemaVersion);
		} else if (entity === "Actor") {
			updateData = migrateActorData(ent.data, worldSchemaVersion);
		} else if (entity === "Scene") {
			updateData = migrateSceneData(ent.data, worldSchemaVersion);
		}
		if (!isObjectEmpty(updateData)) {
			expandObject(updateData);
			updateData._id = ent._id;
			await pack.updateEntity(updateData);
		}
	}
};

const migrateSettings = async function (worldSchemaVersion) {
	if (worldSchemaVersion <= 3) {
		game.settings.set("forbidden-lands", "showCraftingFields", true);
		game.settings.set("forbidden-lands", "showCostField", true);
		game.settings.set("forbidden-lands", "showSupplyField", true);
		game.settings.set("forbidden-lands", "showEffectField", true);
		game.settings.set("forbidden-lands", "showDescriptionField", true);
		game.settings.set("forbidden-lands", "showDrawbackField", true);
		game.settings.set("forbidden-lands", "showAppearanceField", true);
	}
	if (worldSchemaVersion <= 4) {
		game.settings.set("forbidden-lands", "alternativeSkulls", false);
	}
};

/** This class is responsible for rolling dice */
class DiceRoller {
	dices = [];
	lastType = "";
	lastRollName = "";
	lastDamage = 0;

	/**
	 * @param  {string} rollName   Display name for the roll
	 * @param  {number} base       Number of Base dice
	 * @param  {number} skill      Number of Skill dice
	 * @param  {number} gear       Number of Gear dice
	 * @param  {Array}  artifacts  Array of artifact dice objects: [{dice: number of dice, face: number of faces}]
	 * @param  {number} modifier   Increase/decrease amount of skill dice
	 * @param  {number} [damage=0] Weapon damage
	 */
	roll(rollName, base, skill, gear, artifacts, modifier, damage = 0) {
		this.dices = [];
		this.lastType = "skill";
		this.name = rollName;
		let computedSkill = skill + modifier;
		let computedSkillType;
		if (computedSkill > 0) {
			computedSkillType = "skill";
		} else {
			computedSkill = -computedSkill;
			computedSkillType = "skill-penalty";
		}
		this.rollDice(base, "base", 6, 0);
		this.rollDice(computedSkill, computedSkillType, 6, 0);
		this.rollDice(gear, "gear", 6, 0);
		artifacts.forEach((artifact) => {
			this.rollDice(artifact.dice, "artifact", artifact.face);
		});
		this.weaponDamage = damage;
		this.damage = this.weaponDamage;
		this.hasDamage = damage > 0;
		if (this.hasDamage) {
			this.damage = damage - 1;
		}
		this.sendRollToChat(this, false);
	}

	/**
	 * Push the last roll
	 */
	push(data) {
		data.dices.forEach((dice) => {
			if (
				(dice.value < 6 && dice.value > 1) ||
				(dice.value < 6 && ["artifact", "skill", "skill-penalty"].includes(dice.type))
			) {
				let die = new Die({ faces: dice.face, number: 1 });
				die.evaluate();
				dice.value = die.total;
				let successAndWeight = this.getSuccessAndWeight(dice.value, dice.type);
				dice.success = successAndWeight.success;
				dice.weight = successAndWeight.weight;
				dice.rolled = true;
			} else {
				dice.rolled = false;
			}
		});
		if (data.lastType === "spell") {
			this.sendRollSpellToChat(data, true);
		} else {
			this.sendRollToChat(data, true);
		}
	}

	synthetizeFakeRoll(dice) {
		const terms = [];
		for (let die of dice) {
			if (!die.rolled) {
				continue;
			}
			let term = "Die";
			switch (die.type) {
				case "artifact":
					term = `ArtifactD${die.face}`;
					break;
				case "base":
					term = "BaseDie";
					break;
				case "gear":
					term = "GearDie";
					break;
				case "skill":
					term = "SkillDie";
					break;
			}
			terms.push({
				class: term,
				faces: die.face,
				number: 1,
				results: [{ result: die.value, active: true }],
			});
		}
		return { class: "Roll", dice: [], formula: "", terms: terms };
	}

	/**
	 * Display roll in chat
	 *
	 * @param  {boolean} isPushed Whether roll was pushed
	 */
	async sendRollToChat(data, isPushed) {
		data.dices.sort(function (a, b) {
			return b.weight - a.weight;
		});
		let numberOfSword = this.countSword(data);
		let numberOfSkull = this.countSkull(data);
		let rollData = {
			name: data.name,
			isPushed: isPushed,
			isSpell: false,
			sword: numberOfSword,
			skull: numberOfSkull,
			damage: numberOfSword > 0 ? numberOfSword + data.weaponDamage - 1 : 0,
			weaponDamage: data.weaponDamage,
			hasDamage: data.hasDamage,
			dices: data.dices,
			user: game.userId,
		};
		const html = await renderTemplate("systems/forbidden-lands/templates/chat/roll.hbs", rollData);
		let chatData = {
			type: CHAT_MESSAGE_TYPES.ROLL,
			user: game.user._id,
			rollMode: game.settings.get("core", "rollMode"),
			content: html,
		};
		if (["gmroll", "blindroll"].includes(chatData.rollMode)) {
			chatData.whisper = ChatMessage.getWhisperRecipients("GM");
		} else if (chatData.rollMode === "selfroll") {
			chatData.whisper = [game.user];
		}
		chatData["flags.forbidden-lands.rollData"] = rollData;
		const roll = this.synthetizeFakeRoll(data.dices);
		chatData.roll = JSON.stringify(roll);
		ChatMessage.create(chatData);
	}

	async sendRollSpellToChat(data, isPushed) {
		data.dices.sort(function (a, b) {
			return b.weight - a.weight;
		});
		let numberOfSword = this.countSword(data);
		let numberOfSkull = this.countSkull(data);
		let rollData = {
			name: data.name,
			isPushed: isPushed,
			isSpell: true,
			sword: numberOfSword,
			skull: numberOfSkull,
			powerLevel: numberOfSword + this.dices.length,
			hadDamage: false,
			dices: data.dices,
			user: game.userId,
		};
		const html = await renderTemplate("systems/forbidden-lands/templates/chat/roll.hbs", rollData);
		let chatData = {
			user: game.user._id,
			rollMode: game.settings.get("core", "rollMode"),
			content: html,
		};
		if (["gmroll", "blindroll"].includes(chatData.rollMode)) {
			chatData.whisper = ChatMessage.getWhisperRecipients("GM");
		} else if (chatData.rollMode === "selfroll") {
			chatData.whisper = [game.user];
		}
		chatData["flags.forbidden-lands.rollData"] = rollData;
		const roll = this.synthetizeFakeRoll(data.dices);
		chatData.roll = JSON.stringify(roll);
		ChatMessage.create(chatData);
	}

	rollSpell(testName, base, success) {
		this.dices = [];
		this.lastType = "spell";
		this.name = testName;
		this.rollDice(base, "base", 6, success);
		this.damage = 0;
		this.sendRollSpellToChat(this, false);
	}

	/**
	 * Roll a set of dice
	 *
	 * @param  {number} numberOfDice     How many dice to roll
	 * @param  {string} typeOfDice       Base/skill/gear
	 * @param  {number} numberOfFaces    What dice to roll
	 * @param  {number} automaticSuccess For spells
	 */
	rollDice(numberOfDice, typeOfDice, numberOfFaces, automaticSuccess) {
		if (numberOfDice > 0) {
			let die = new Die({ faces: numberOfFaces, number: numberOfDice });
			die.evaluate();
			die.results.forEach((roll) => {
				let result = roll.result;
				let rolled = true;
				if (automaticSuccess > 0) {
					result = numberOfFaces;
					rolled = false;
					automaticSuccess -= 1;
				}
				let successAndWeight = this.getSuccessAndWeight(result, typeOfDice);
				this.dices.push({
					value: result,
					type: typeOfDice,
					success: successAndWeight.success,
					weight: successAndWeight.weight,
					face: numberOfFaces,
					rolled: rolled,
				});
			});
		}
	}

	/**
	 * Retrieves amount of successes from a single die
	 * and weight for ordering during display
	 *
	 * @param  {number} diceValue
	 * @param  {string} diceType
	 */
	getSuccessAndWeight(diceValue, diceType) {
		if (diceValue === 12) {
			return { success: 4, weight: 4 };
		} else if (diceValue >= 10) {
			return { success: 3, weight: 3 };
		} else if (diceValue >= 8) {
			return { success: 2, weight: 2 };
		} else if (diceValue >= 6) {
			if (diceType === "skill-penalty") {
				return { success: -1, weight: -1 };
			} else {
				return { success: 1, weight: 1 };
			}
		} else if (diceValue === 1 && diceType !== "skill-penalty" && diceType !== "skill") {
			return { success: 0, weight: -2 };
		} else {
			return { success: 0, weight: 0 };
		}
	}

	/**
	 * Count total successes
	 */
	countSword(data) {
		if (!data) data = this;
		let numberOfSword = 0;
		data.dices.forEach((dice) => {
			numberOfSword = numberOfSword + dice.success;
		});
		return numberOfSword;
	}

	/**
	 * Count total failures
	 */
	countSkull(data) {
		if (!data) data = this;
		let numberOfSkull = 0;
		data.dices.forEach((dice) => {
			if (dice.value === 1 && (dice.type === "base" || dice.type === "gear")) {
				numberOfSkull++;
			}
		});
		return numberOfSkull;
	}
}

class RollDialog {
	/**
	 * Display roll dialog and execute the roll.
	 *
	 * @param  {string}        rollName
	 * @param  {object|number} baseDefault     {name: "somename", value: 5} | 5
	 * @param  {object|number} skillDefault    {name: "somename", value: 5} | 5
	 * @param  {object|number} gearDefault     {name: "somename", value: 5} | 5
	 * @param  {string}        artifactDefault
	 * @param  {number}        modifierDefault
	 * @param  {number}        damage
	 * @param  {DiceRoller}    diceRoller
	 * @param  {callback}      [onAfterRoll]
	 */
	static prepareRollDialog(
		rollName,
		baseDefault,
		skillDefault,
		gearDefault,
		artifactDefault,
		modifierDefault,
		damage,
		diceRoller,
		onAfterRoll,
	) {
		if (!diceRoller) {
			throw new Error("DiceRoller object must be passed to prepareRollDialog()");
		}
		onAfterRoll = onAfterRoll || function () {};

		if (typeof baseDefault !== "object") baseDefault = { name: "DICE.BASE", value: baseDefault };
		if (typeof skillDefault !== "object") skillDefault = { name: "DICE.SKILL", value: skillDefault };
		if (typeof gearDefault !== "object") gearDefault = { name: "DICE.GEAR", value: gearDefault };

		let baseHtml = this.buildInputHtmlDialog(baseDefault.name, "base", baseDefault.value);
		let skillHtml = this.buildInputHtmlDialog(skillDefault.name, "skill", skillDefault.value);
		let gearHtml = this.buildInputHtmlDialog(gearDefault.name, "gear", gearDefault.value);
		let artifactHtml = this.buildInputHtmlDialog("DICE.ARTIFACTS", "artifacts", artifactDefault);
		let modifierHtml = this.buildInputHtmlDialog("DICE.MODIFIER", "modifier", modifierDefault);

		let d = new Dialog({
			title:
				rollName !== "DICE.ROLL"
					? game.i18n.localize("DICE.ROLL") + ": " + game.i18n.localize(rollName)
					: game.i18n.localize("DICE.ROLL"),
			content: this.buildDivHtmlDialog(baseHtml + skillHtml + gearHtml + artifactHtml + modifierHtml),
			buttons: {
				roll: {
					icon: '<i class="fas fa-check"></i>',
					label: game.i18n.localize("DICE.ROLL"),
					callback: (html) => {
						let base = html.find("#base")[0].value;
						let skill = html.find("#skill")[0].value;
						let gear = html.find("#gear")[0].value;
						let artifact = this.parseArtifact(html.find("#artifacts")[0].value);
						let modifier = html.find("#modifier")[0].value;
						diceRoller.roll(
							game.i18n.localize(rollName),
							parseInt(base, 10),
							parseInt(skill, 10),
							parseInt(gear, 10),
							artifact,
							parseInt(modifier, 10),
							parseInt(damage, 10),
						);
						onAfterRoll(diceRoller);
					},
				},
				cancel: {
					icon: '<i class="fas fa-times"></i>',
					label: game.i18n.localize("DICE.CANCEL"),
					callback: () => {},
				},
			},
			default: "roll",
			close: () => {},
			render: this.activateListeners,
		});
		d.render(true);
	}

	/**
	 * @param {object}   spell       Spell data
	 * @param {Function} onAfterRoll Callback that is executed after roll is made
	 */
	static prepareSpellDialog(spell, onAfterRoll) {
		const diceRoller = new DiceRoller();
		onAfterRoll = onAfterRoll || function () {};

		let baseHtml = this.buildInputHtmlDialog("DICE.BASE", "base", 1);
		let successHtml = this.buildInputHtmlDialog("DICE.AUTOMATIC_SUCCESS", "success", 0);
		let d = new Dialog({
			title: game.i18n.localize("ITEM.TypeSpell") + ": " + spell.name,
			content: this.buildDivHtmlDialog(baseHtml + successHtml),
			buttons: {
				roll: {
					icon: '<i class="fas fa-check"></i>',
					label: game.i18n.localize("DICE.ROLL"),
					callback: (html) => {
						let base = html.find("#base")[0].value;
						let success = html.find("#success")[0].value;
						diceRoller.rollSpell(spell.name, parseInt(base, 10), parseInt(success, 10));
						onAfterRoll(diceRoller);
					},
				},
				cancel: {
					icon: '<i class="fas fa-times"></i>',
					label: game.i18n.localize("DICE.CANCEL"),
					callback: () => {},
				},
			},
			default: "roll",
			close: () => {},
			render: this.activateListeners,
		});
		d.render(true);
	}

	/**
	 * @param  {string} divContent
	 */
	static buildDivHtmlDialog(divContent) {
		return "<div class='flex row roll-dialog'><table>" + divContent + "</table></div>";
	}

	/**
	 * @param  {string} diceName
	 * @param  {string} diceId
	 * @param  {number} diceValue
	 */
	static buildInputHtmlDialog(diceName, diceId, diceValue) {
		let row = "<tr>";
		row += "<td><b>" + game.i18n.localize(diceName) + "</b></td>";
		row += "<td style='text-align: center;'>";
		if (diceName !== "DICE.ARTIFACTS") {
			row +=
				"<a class='modifier-button' data-operator='minus' data-field='" +
				diceId +
				"'><i class='fas fa-minus-square'></i></a>";
		}
		row += "</td>";
		row += "<td style='text-align: center;'>";
		row += "<input id='" + diceId + "' style='text-align: center' type='text' value='" + diceValue + "'/>";
		row += "</td>";
		row += "<td style='text-align: center;'>";
		if (diceName !== "DICE.ARTIFACTS") {
			row +=
				"<a class='modifier-button' data-operator='plus' data-field='" +
				diceId +
				"'><i class='fas fa-plus-square'></i></a>";
		}
		row += "</td>";
		row += "</tr>";
		return row;
	}

	/**
	 * Parse artifact dice string
	 *
	 * @param  {string} artifact
	 */
	static parseArtifact(artifact) {
		let regex = /([0-9]*)d([0-9]*)/gi;
		let regexMatch;
		let artifacts = [];
		while ((regexMatch = regex.exec(artifact))) {
			artifacts.push({ dice: +regexMatch[1] || 1, face: +regexMatch[2] });
		}
		return artifacts;
	}

	static activateListeners(html) {
		html.find(".modifier-button").click((ev) => {
			const field = $(ev.currentTarget).data("field");
			const operator = $(ev.currentTarget).data("operator");
			const input = html.find("#" + field);
			let value = parseInt(input.val(), 10) || 0;
			value += operator === "plus" ? 1 : -1;
			input.val(value);
		});
	}
}

class ForbiddenLandsActorSheet extends ActorSheet {
	altInteraction = game.settings.get("forbidden-lands", "alternativeSkulls");
	diceRoller = new DiceRoller();

	/**
	 * @override
	 * Extends the sheet drop handler for system specific usages
	 */
	async _onDrop(event) {
		let dragData = JSON.parse(event.dataTransfer.getData("text/plain"));

		// To be extended if future features add more drop functionality
		if (dragData.type === "itemDrop") this.actor.createEmbeddedEntity("OwnedItem", dragData.item);
		// Call base _onDrop for normal FVTT drop handling
		else super._onDrop(event);
	}

	activateListeners(html) {
		super.activateListeners(html);
		// Attribute markers
		html.find(".change-attribute").on("click contextmenu", (ev) => {
			const attributeName = $(ev.currentTarget).data("attribute");
			const attribute = this.actor.data.data.attribute[attributeName];
			let value = attribute.value;
			if ((ev.type === "click" && !this.altInteraction) || (ev.type === "contextmenu" && this.altInteraction)) {
				value = Math.max(value - 1, 0);
			} else if (
				(ev.type === "contextmenu" && !this.altInteraction) ||
				(ev.type === "click" && this.altInteraction)
			) {
				value = Math.min(value + 1, attribute.max);
			}
			this.actor.update({
				["data.attribute." + attributeName + ".value"]: value,
			});
		});

		// Willpower markers
		html.find(".change-willpower").on("click contextmenu", (ev) => {
			const attribute = this.actor.data.data.bio.willpower;
			let value = attribute.value;
			if ((ev.type === "click" && !this.altInteraction) || (ev.type === "contextmenu" && this.altInteraction)) {
				value = Math.max(value - 1, 0);
			} else if (
				(ev.type === "contextmenu" && !this.altInteraction) ||
				(ev.type === "click" && this.altInteraction)
			) {
				value = Math.min(value + 1, attribute.max);
			}
			this.actor.update({ "data.bio.willpower.value": value });
		});

		// Items
		html.find(".item-edit").click((ev) => {
			const div = $(ev.currentTarget).parents(".item");
			const item = this.actor.getOwnedItem(div.data("itemId"));
			item.sheet.render(true);
		});
		html.find(".item-delete").click((ev) => {
			const div = $(ev.currentTarget).parents(".item");
			this.actor.deleteOwnedItem(div.data("itemId"));
			div.slideUp(200, () => this.render(false));
		});
		html.find(".item-post").click((ev) => {
			const div = $(ev.currentTarget).parents(".item");
			const item = this.actor.getOwnedItem(div.data("itemId"));
			item.sendToChat();
		});
		html.find(".change-item-bonus").on("click contextmenu", (ev) => {
			const itemId = $(ev.currentTarget).data("itemId");
			const item = this.actor.getOwnedItem(itemId);
			let value = item.data.data.bonus.value;
			if ((ev.type === "click" && !this.altInteraction) || (ev.type === "contextmenu" && this.altInteraction)) {
				value = Math.max(value - 1, 0);
			} else if (
				(ev.type === "contextmenu" && !this.altInteraction) ||
				(ev.type === "click" && this.altInteraction)
			) {
				value = Math.min(value + 1, item.data.data.bonus.max);
			}
			item.update({
				"data.bonus.value": value,
			});
		});

		// Rolls
		html.find(".roll-attribute").click((ev) => {
			const attributeName = $(ev.currentTarget).data("attribute");
			const attribute = this.actor.data.data.attribute[attributeName];
			let modifiers = this.getRollModifiers(attribute.label, null);
			RollDialog.prepareRollDialog(
				attribute.label,
				{ name: attribute.label, value: attribute.value },
				0,
				0,
				modifiers.artifacts.join(" "),
				modifiers.modifier,
				0,
				this.diceRoller,
				null,
			);
		});
		html.find(".roll-skill").click((ev) => {
			const skillName = $(ev.currentTarget).data("skill");
			const skill = this.actor.data.data.skill[skillName];
			const attribute = this.actor.data.data.attribute[skill.attribute];
			let modifiers = this.getRollModifiers(attribute.label, null);
			modifiers = this.getRollModifiers(skill.label, modifiers);
			RollDialog.prepareRollDialog(
				skill.label,
				{ name: attribute.label, value: attribute.value },
				{ name: skill.label, value: skill.value },
				0,
				modifiers.artifacts.join(" "),
				modifiers.modifier,
				0,
				this.diceRoller,
				null,
			);
		});
		html.find(".roll-weapon").click((ev) => {
			const itemId = $(ev.currentTarget).data("itemId");
			const weapon = this.actor.getOwnedItem(itemId);
			const action = $(ev.currentTarget).data("action");
			let testName = action || weapon.name;
			let attribute;
			let skill;
			if (weapon.data.data.category === "melee") {
				attribute = this.actor.data.data.attribute.strength;
				skill = this.actor.data.data.skill.melee;
			} else {
				attribute = this.actor.data.data.attribute.agility;
				skill = this.actor.data.data.skill.marksmanship;
			}
			let bonus = this.parseBonus(weapon.data.data.bonus.value);
			let modifiers = this.parseModifiers(weapon.data.data.skillBonus);
			if (weapon.data.data.artifactBonus) {
				modifiers.artifacts.splice(0, 0, weapon.data.data.artifactBonus);
			}
			modifiers = this.getRollModifiers(attribute.label, modifiers);
			modifiers = this.getRollModifiers(skill.label, modifiers);
			if (action) {
				modifiers = this.getRollModifiers(action, modifiers);
			}

			if (weapon.data.data.category === "melee" && action === "ACTION.PARRY") {
				// Adjust parry action modifiers based on weapon features
				const parrying = weapon.data.data.features.parrying;
				if (!parrying) {
					modifiers.modifier -= 2;
				}
			}

			RollDialog.prepareRollDialog(
				testName,
				{ name: attribute.label, value: attribute.value },
				{ name: skill.label, value: skill.value },
				bonus,
				modifiers.artifacts.join(" "),
				modifiers.modifier,
				action ? 0 : weapon.data.data.damage,
				this.diceRoller,
				null,
			);
		});
		html.find(".roll-spell").click((ev) => {
			const itemId = $(ev.currentTarget).data("itemId");
			const spell = this.actor.getOwnedItem(itemId);
			RollDialog.prepareSpellDialog(spell, null);
		});
		html.find(".roll-action").click((ev) => {
			const rollName = $(ev.currentTarget).data("action");
			const skillName = $(ev.currentTarget).data("skill");
			const skill = this.actor.data.data.skill[skillName];
			const attribute = this.actor.data.data.attribute[skill.attribute];
			let modifiers = this.getRollModifiers(attribute.label, null);
			modifiers = this.getRollModifiers(skill.label, modifiers);
			modifiers = this.getRollModifiers(rollName, modifiers);
			RollDialog.prepareRollDialog(
				rollName,
				{ name: attribute.label, value: attribute.value },
				{ name: skill.label, value: skill.value },
				0,
				modifiers.artifacts.join(" "),
				modifiers.modifier,
				0,
				this.diceRoller,
				null,
			);
		});
		html.find(".quantity").on("blur", (ev) => {
			const itemId = ev.currentTarget.parentElement.dataset.itemId;
			this.actor.updateOwnedItem({
				_id: itemId,
				"data.quantity": ev.currentTarget.value,
			});
		});
	}

	parseModifiers(str) {
		let sep = /[\s+]+/;
		let artifacts = [];
		let modifier = 0;
		if (typeof str === "string") {
			str.split(sep).forEach((item) => {
				if (this.isArtifact(item)) {
					artifacts.push(item);
				} else {
					item = parseInt(item, 10);
					if (!isNaN(item)) {
						modifier += item;
					}
				}
			});
		} else if (typeof str === "number") {
			modifier = str;
		}
		return {
			artifacts: artifacts,
			modifier: modifier,
		};
	}

	isArtifact(artifact) {
		let regex = /([0-9]*)d([0-9]*)/i;
		return !!regex.exec(artifact);
	}

	parseBonus(bonus) {
		let regex = /([0-9]*[^d+-])/;
		let regexMatch = regex.exec(bonus);
		if (regexMatch != null) {
			return regex.exec(bonus)[1];
		} else {
			return 0;
		}
	}

	getRollModifiers(skillLabel, modifiers) {
		if (!modifiers) {
			modifiers = { modifier: 0, artifacts: [] };
		}
		this.actor.items.forEach((item) => {
			let rollModifiers = item.data.data.rollModifiers;
			if (rollModifiers) {
				Object.values(rollModifiers).forEach((mod) => {
					if (mod && mod.name === skillLabel) {
						let parsed = this.parseModifiers(mod.value);
						modifiers.modifier += parsed.modifier;
						modifiers.artifacts = modifiers.artifacts.concat(parsed.artifacts);
					}
				});
			}
		});
		return modifiers;
	}
	async _renderInner(data, options) {
		data.alternativeSkulls = this.altInteraction;
		return super._renderInner(data, options);
	}
	computerItemEncumbrance(data) {
		const config = game.fbl.config.encumbrance;
		const type = data.type;
		const weight = data.data?.weight;
		if (data.type === "rawMaterial") return 1 * Number(data.data.quantity);
		if (type !== "gear" && type !== "armor" && type !== "weapon") return null;
		return Number(config[weight] ?? 1) ?? Number(weight) ?? 1;
	}
}

class CharacterConverter {
	constructor(dataset) {
		this.character = null;
		this.dataset = dataset;
	}

	async convert(character) {
		this.character = character;
		let actorData = {
			data: this.buildCharacterData(),
			items: this.buildCharacterItems(),
		};

		return actorData;
	}

	buildCharacterData() {
		const kin = this.dataset.kin[this.character.kin];
		const age = this.character.age;
		// eslint-disable-next-line no-unused-vars
		age.ageKey;
		const profession = this.dataset.profession[this.character.profession];

		let data = {
			bio: {
				kin: { value: kin.name },
				age: { value: age.ageNumber },
				profession: { value: profession.name },
				note: { value: this.generateNotes(this.character) },
			},
			consumable: {
				food: { value: profession.consumables.food },
				water: { value: profession.consumables.water },
				arrows: { value: profession.consumables.arrows },
				torches: { value: profession.consumables.torches },
			},
			currency: {
				gold: { value: profession.currency.gold > 0 ? this.rollNumber(1, profession.currency.gold) : 0 },
				silver: { value: profession.currency.silver > 0 ? this.rollNumber(1, profession.currency.silver) : 0 },
				copper: { value: profession.currency.copper > 0 ? this.rollNumber(1, profession.currency.copper) : 0 },
			},
			attribute: this.generateAttributes(),
			skill: this.generateSkills(),
		};

		return data;
	}

	buildCharacterItems() {
		let items = [];

		items = items.concat(this.buildTalents());
		items = items.concat(this.buildGear());
		items = items.concat(this.buildEventGear());

		return items;
	}

	buildEventGear() {
		let gear = [];
		for (let i = 0; i < this.character.formativeEvents.length; i++) {
			let event = this.character.formativeEvents[i];
			gear.push(this.createNewItem(event.items));
		}

		return gear;
	}

	buildGear() {
		const profession = this.dataset.profession[this.character.profession];
		let gear = [];
		for (let i = 0; i < profession.equipment.length; i++) {
			let item = profession.equipment[i];
			if (Array.isArray(item)) {
				// array from which only one item must be picked
				item = item[this.rollNumber(0, item.length - 1)];
			}
			gear.push(this.getExactItem(item));
		}

		return gear;
	}

	buildTalents() {
		const kin = this.dataset.kin[this.character.kin];
		const profession = this.dataset.profession[this.character.profession];
		let talents = [
			this.getItem(kin.talent, "talent"),
			this.getItem(profession.paths[this.character.path], "talent"),
		];
		for (let i = 0; i < this.character.formativeEvents.length; i++) {
			const event = this.character.formativeEvents[i];
			talents.push(this.getExactItem(event.talent, "talent"));
		}

		return talents;
	}

	getExactItem(name, type = false) {
		const nameLowerCase = name.toLowerCase();
		type = type ? type.toLowerCase() : type;
		let item = game.items.find(
			(i) => i.name.toLowerCase() === nameLowerCase && (type === false || i.type === type),
		);
		if (!item) {
			item = this.createNewItem(name, type);
		}
		return item;
	}

	getItem(name, type = false) {
		const nameLowerCase = name.toLowerCase();
		type = type ? type.toLowerCase() : type;
		let item = game.items.find(
			(i) => i.name.toLowerCase().includes(nameLowerCase) && (type === false || i.type === type),
		);
		if (!item) {
			item = this.createNewItem(name, type);
		}
		return item;
	}

	createNewItem(name, type = false) {
		let ItemClass = CONFIG.Item.entityClass;
		return new ItemClass({
			name: name,
			type: type || "gear",
			data: type === "talent" ? {} : { weight: "tiny" },
		});
	}

	generateAttributes() {
		let attributes = JSON.parse(JSON.stringify(this.character.childhood.attributes));
		const agePenalty = this.character.age.ageKey;

		const attrs = ["strength", "agility", "wits", "empathy"];
		for (let i = 0; i < agePenalty; i++) {
			attributes[attrs[this.rollNumber(0, 3)]] -= 1;
		}

		return {
			strength: { value: attributes.strength, max: attributes.strength },
			agility: { value: attributes.agility, max: attributes.agility },
			wits: { value: attributes.wits, max: attributes.wits },
			empathy: { value: attributes.empathy, max: attributes.empathy },
		};
	}

	generateSkills() {
		let tmpSkills = JSON.parse(JSON.stringify(this.character.childhood.skills));
		let skills = {};

		for (let i = 0; i < this.character.formativeEvents.length; i++) {
			const eventSkills = this.character.formativeEvents[i].skills;
			for (const skillName in eventSkills) {
				// eslint-disable-next-line no-prototype-builtins
				if (eventSkills.hasOwnProperty(skillName)) {
					if (tmpSkills[skillName] === undefined) {
						tmpSkills[skillName] = 0;
					} else {
						tmpSkills[skillName] = parseInt(tmpSkills[skillName]);
					}
					tmpSkills[skillName] += parseInt(eventSkills[skillName]);
				}
			}
		}
		for (const skillName in tmpSkills) {
			// eslint-disable-next-line no-prototype-builtins
			if (tmpSkills.hasOwnProperty(skillName)) {
				skills[skillName] = { value: tmpSkills[skillName] };
			}
		}
		return skills;
	}

	generateNotes(character) {
		const childhood = character.childhood;
		let notes = `<h3>Childhood: ${childhood.name}</h3><p>${childhood.description}</p>`;
		for (let i = 0; i < character.formativeEvents.length; i++) {
			const event = character.formativeEvents[i];
			notes += `<h3>Formative Event: ${event.name}</h3><p>${event.description}</p>`;
		}
		const noteWrapper = `<div class="fbl-core">${notes}</div>`;
		return noteWrapper;
	}

	rollNumber(min, max) {
		return Math.floor(Math.random() * (max + 1 - min)) + min;
	}
}

class ForbiddenLandsCharacterGenerator extends Application {
	constructor(dataset = {}, existActor, options = {}) {
		super(options);

		this.character = null;
		this.existActor = existActor;
		this.dataset = dataset;
	}

	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			classes: ["forbidden-lands", "sheet", "actor"],
			template: "systems/forbidden-lands/templates/character-generator.hbs",
			title: game.i18n.localize("FLCG.TITLE"),
			width: 700,
			height: 840,
			resizable: false,
		});
	}

	static async loadDataset() {
		const datasetDir = game.settings.get("forbidden-lands", "datasetDir");
		const resp = await fetch(datasetDir + "/dataset.json").catch((_err) => {
			return {};
		});
		return resp.json();
	}

	getData() {
		const data = super.getData();
		if (this.character === null) {
			this.character = this.generateCharacter();
		}

		data.character = this.character;
		data.dataset = this.dataset;
		data.dataset.childhood = this.dataset.kin[this.character.kin].childhood;
		data.dataset.paths = this.dataset.profession[this.character.profession].paths;
		data.dataset.formativeEvents = this.dataset.profession[this.character.profession].formativeEvents;

		return data;
	}

	activateListeners(html) {
		super.activateListeners(html);

		html.find(".chargen-randomize-all").click(this.handleRandomizeAll.bind(this));
		html.find(".chargen-create-actor").click(this.handleCreateActor.bind(this));

		html.find(".chargen-roll-kin").click(this.handleRollKin.bind(this));
		html.find(".chargen-roll-age").click(this.handleRollAge.bind(this));
		html.find(".chargen-roll-childhood").click(this.handleRollChildhood.bind(this));
		html.find(".chargen-roll-profession").click(this.handleRollProfession.bind(this));
		html.find(".chargen-roll-path").click(this.handleRollPath.bind(this));
		html.find(".chargen-roll-event").click(this.handleRollEvent.bind(this));

		html.find(".chargen-select-kin").change(this.handleInputKin.bind(this));
		html.find(".chargen-age-input").change(this.handleInputAge.bind(this));
		html.find(".chargen-select-childhood").change(this.handleInputChildhood.bind(this));
		html.find(".chargen-select-profession").change(this.handleInputProfession.bind(this));
		html.find(".chargen-select-path").change(this.handleInputPath.bind(this));
		html.find(".chargen-select-event").change(this.handleInputEvent.bind(this));
	}

	_getHeaderButtons() {
		let buttons = super._getHeaderButtons();

		return buttons;
	}

	async handleCreateActor() {
		const coverter = new CharacterConverter(this.dataset);
		const updateData = await coverter.convert(this.character);
		await this.existActor.update({ ["data"]: updateData.data });
		await this.existActor.createEmbeddedEntity("OwnedItem", updateData.items);

		return false;
	}

	handleInputKin(event) {
		const kinKey = $(event.currentTarget).val();
		this.character = this.setKin(this.character, kinKey);
		this.render(true);

		return false;
	}

	handleInputAge(event) {
		const mapping = ["Young", "Adult", "Old"];
		const ageNumber = parseInt($(event.currentTarget).val());
		const kin = this.dataset.kin[this.character.kin];
		let ageKey = 2;
		for (let i = 0; i < 3; i++) {
			const range = kin.age[i];
			if (ageNumber >= range[0] && ageNumber <= range[1]) {
				ageKey = i;
				break;
			}
		}
		this.character.age = { ageKey: ageKey, ageNumber: ageNumber, ageString: mapping[ageKey] };
		this.character = this.rollFormativeEvents(this.character);

		this.render(true);

		return false;
	}

	handleInputChildhood(event) {
		const childhoodKey = $(event.currentTarget).val();
		const kin = this.dataset.kin[this.character.kin];
		this.character.childhood = kin.childhood[childhoodKey];

		this.render(true);

		return false;
	}

	handleInputProfession(event) {
		const professionKey = $(event.currentTarget).val();
		this.character.profession = professionKey;
		this.character = this.rollPath(this.character);
		this.character.formativeEvents = false; // force re-roll
		this.character = this.rollFormativeEvents(this.character);

		this.render(true);

		return false;
	}

	handleInputPath(event) {
		const pathKey = parseInt($(event.currentTarget).val());
		this.character.path = pathKey;
		this.render(true);

		return false;
	}

	handleInputEvent(event) {
		const el = $(event.currentTarget);
		const id = parseInt(el.data("key"));
		const eventKey = el.val();
		const profession = this.dataset.profession[this.character.profession];

		this.character.formativeEvents[id] = profession.formativeEvents[eventKey];

		this.render(true);

		return false;
	}

	handleRollKin(_event) {
		this.character = this.setKin(this.character);
		this.render(true);

		return false;
	}

	handleRollAge(_event) {
		this.character.age = this.rollAge(this.dataset.kin[this.character.kin].age);
		this.character = this.rollFormativeEvents(this.character);

		this.render(true);

		return false;
	}

	handleRollChildhood(_event) {
		const kin = this.dataset.kin[this.character.kin];
		this.character.childhood = this.rollOn(kin.childhood);

		this.render(true);

		return false;
	}

	handleRollProfession(_event) {
		this.character.profession = this.rollOn(this.dataset.profession).key;
		this.character = this.rollPath(this.character);
		this.character.formativeEvents = false; // force re-roll
		this.character = this.rollFormativeEvents(this.character);

		this.render(true);

		return false;
	}

	handleRollPath(_event) {
		this.character = this.rollPath(this.character);
		this.render(true);

		return false;
	}

	handleRollEvent(event) {
		const profession = this.dataset.profession[this.character.profession];
		let button = $(event.currentTarget);
		const id = parseInt(button.data("key"));
		let rolled = [];
		let newEvent = {};
		for (let i = 0; i < this.character.formativeEvents.length; i++) {
			if (i === id) continue;
			const formativeEvent = this.character.formativeEvents[i];
			rolled.push(formativeEvent.key);
		}

		do {
			newEvent = this.rollOn(profession.formativeEvents);
		} while (rolled.includes(newEvent.key));
		this.character.formativeEvents[id] = newEvent;

		this.render(true);

		return false;
	}

	handleRandomizeAll(_event) {
		this.character = this.generateCharacter();
		this.render(true);

		return false;
	}

	generateCharacter() {
		let character = {};
		character = this.setKin(character);
		let profession = this.rollOn(this.dataset.profession);
		character.profession = profession.key;
		character = this.rollPath(character);
		character = this.rollFormativeEvents(character);

		return character;
	}

	setKin(character, kinKey) {
		let kin = kinKey ? this.dataset.kin[kinKey] : this.rollOn(this.dataset.kin);

		character.kin = kin.key;
		if (character.age === undefined) {
			character.age = this.rollAge(kin.age);
		} else {
			character.age.ageNumber = this.rollNumber(
				kin.age[character.age.ageKey][0],
				kin.age[character.age.ageKey][1],
			);
		}
		character.childhood = this.rollOn(kin.childhood);

		return character;
	}

	rollPath(character) {
		character.path = this.rollNumber(0, 2);

		return character;
	}

	rollFormativeEvents(character) {
		let profession = this.dataset.profession[character.profession];
		let formativeEvents = [];
		let rolled = [];
		let event = {};
		if (!character.formativeEvents) {
			for (let i = 0; i < character.age.ageKey + 1; i++) {
				do {
					event = this.rollOn(profession.formativeEvents);
				} while (rolled.includes(event.key));

				rolled.push(event.key);
				formativeEvents.push(event);
			}
		} else if (character.formativeEvents.length < character.age.ageKey + 1) {
			for (let i = 0; i < character.formativeEvents.length; i++) {
				const element = character.formativeEvents[i];
				rolled.push(element.key);
				formativeEvents.push(element);
			}
			for (let i = character.formativeEvents.length; i < character.age.ageKey + 1; i++) {
				do {
					event = this.rollOn(profession.formativeEvents);
				} while (rolled.includes(event.key));

				rolled.push(event.key);
				formativeEvents.push(event);
			}
		} else if (character.formativeEvents.length > character.age.ageKey + 1) {
			formativeEvents = character.formativeEvents.slice(0, character.age.ageKey + 1);
		} else {
			// no change needed
			formativeEvents = character.formativeEvents;
		}
		character.formativeEvents = formativeEvents;

		return character;
	}

	rollOn(options) {
		let rollTable = this.buildRollTable(options);
		return options[this.rollTable(rollTable)];
	}

	rollAge(ageRanges) {
		const mapping = ["Young", "Adult", "Old"];
		let age = {};
		age.ageKey = this.rollNumber(0, 2);
		age.ageString = mapping[age.ageKey];
		age.ageNumber = this.rollNumber(ageRanges[age.ageKey][0], ageRanges[age.ageKey][1]);

		return age;
	}

	buildRollTable(options) {
		let rollTable = [];
		for (const key in options) {
			// eslint-disable-next-line no-prototype-builtins
			if (options.hasOwnProperty(key)) {
				const element = options[key];
				rollTable = rollTable.concat(Array(element.weight).fill(element.key));
			}
		}
		return rollTable;
	}

	rollNumber(min, max) {
		return Math.floor(Math.random() * (max + 1 - min)) + min;
	}

	rollTable(rollTable) {
		return rollTable[this.rollNumber(0, rollTable.length - 1)];
	}
}

class ForbiddenLandsCharacterSheet extends ForbiddenLandsActorSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			classes: ["forbidden-lands", "sheet", "actor"],
			template: "systems/forbidden-lands/templates/character.hbs",
			width: 700,
			height: 770,
			resizable: false,
			scrollY: [
				".armors .item-list .items",
				".critical-injuries .item-list .items",
				".gears.item-list .items",
				".spells .item-list .items",
				".talents .item-list .items",
				".weapons .item-list .items",
			],
			tabs: [
				{
					navSelector: ".sheet-tabs",
					contentSelector: ".sheet-body",
					initial: "main",
				},
			],
		});
	}

	getData() {
		const data = super.getData();
		this.computeSkills(data);
		this.computeItems(data);
		this.computeEncumbrance(data);
		return data;
	}

	activateListeners(html) {
		super.activateListeners(html);
		html.find(".item-create").click((ev) => {
			this.onItemCreate(ev);
		});
		html.find(".condition").click(async (ev) => {
			const conditionName = $(ev.currentTarget).data("condition");
			const conditionValue = this.actor.data.data.condition[conditionName].value;
			if (game.fbl.config.conditions.includes(conditionName))
				this.actor.update({ [`data.condition.${conditionName}.value`]: !conditionValue });
			this._render();
		});
		html.find(".roll-armor.specific").click((ev) => {
			const itemId = $(ev.currentTarget).data("itemId");
			const armor = this.actor.getOwnedItem(itemId);
			let testName = armor.data.name;
			let base;
			let skill;
			if (armor.data.data.part === "shield") {
				base = {
					name: this.actor.data.data.attribute.strength.label,
					value: this.actor.data.data.attribute.strength.value,
				};
				skill = {
					name: this.actor.data.data.skill.melee.label,
					value: this.actor.data.data.skill.melee.value,
				};
			} else {
				base = 0;
				skill = 0;
			}
			RollDialog.prepareRollDialog(
				testName,
				base,
				skill,
				armor.data.data.bonus.value,
				"",
				0,
				0,
				this.diceRoller,
				null,
			);
		});
		html.find(".roll-armor.total").click(() => {
			let armorTotal = 0;
			const items = this.actor.items;
			items.forEach((item) => {
				if (item.type === "armor" && item.data.data.part !== "shield") {
					armorTotal += parseInt(item.data.data.bonus.value, 10);
				}
			});
			RollDialog.prepareRollDialog("HEADER.ARMOR", 0, 0, armorTotal, "", 0, 0, this.diceRoller, null);
		});
		html.find(".roll-consumable").click((ev) => {
			const consumable = this.actor.data.data.consumable[$(ev.currentTarget).data("consumable")];
			const consumableName = game.i18n.localize(consumable.label);
			if (consumable.value === 6) {
				this.diceRoller.roll(consumableName, 0, 1, 0, [], 0);
			} else if (consumable.value > 6) {
				this.diceRoller.roll(consumableName, 0, 0, 0, [{ dice: 1, face: consumable.value }], 0);
			}
		});
		html.find(".currency-button").on("click contextmenu", (ev) => {
			const currency = $(ev.currentTarget).data("currency");
			const operator = $(ev.currentTarget).data("operator");
			const modifier = ev.type === "contextmenu" ? 5 : 1;
			let coins = [
				this.actor.data.data.currency.gold.value,
				this.actor.data.data.currency.silver.value,
				this.actor.data.data.currency.copper.value,
			];
			let i = { gold: 0, silver: 1, copper: 2 }[currency];
			if (operator === "plus") {
				coins[i] += modifier;
			} else {
				coins[i] -= modifier;
				for (; i >= 0; --i) {
					if (coins[i] < 0 && i > 0) {
						coins[i - 1] -= 1;
						coins[i] += 10;
					}
				}
			}
			if (coins[0] >= 0) {
				this.actor.update({
					"data.currency.gold.value": coins[0],
					"data.currency.silver.value": coins[1],
					"data.currency.copper.value": coins[2],
				});
			}
		});
	}

	computeSkills(data) {
		for (let skill of Object.values(data.data.skill)) {
			skill[`has${skill?.attribute?.capitalize()}`] = false;
			if (game.fbl.config.attributes.includes(skill.attribute))
				skill[`has${skill.attribute.capitalize()}`] = true;
		}
	}

	computeItems(data) {
		for (let item of Object.values(data.items)) {
			if (game.fbl.config.itemTypes.includes(item.type)) item[`is${item.type.capitalize()}`] = true;
		}
	}

	computeEncumbrance(data) {
		let weightCarried = 0;
		for (let item of Object.values(data.items)) {
			weightCarried += this.computerItemEncumbrance(item);
		}
		for (let consumable of Object.values(data.data.consumable)) {
			if (consumable.value > 0) {
				weightCarried += 1;
			}
		}
		const coinsCarried =
			parseInt(data.data.currency.gold.value) +
			parseInt(data.data.currency.silver.value) +
			parseInt(data.data.currency.copper.value);
		weightCarried += Math.floor(coinsCarried / 100) * 0.5;
		let modifiers = this.getRollModifiers("CARRYING_CAPACITY", null);
		const weightAllowed = data.data.attribute.strength.max * 2 + modifiers.modifier;
		data.data.encumbrance = {
			value: weightCarried,
			max: weightAllowed,
			over: weightCarried > weightAllowed,
		};
	}

	onItemCreate(event) {
		event.preventDefault();
		let header = event.currentTarget;
		let data = duplicate(header.dataset);
		data.name = `New ${data.type.capitalize()}`;
		this.actor.createEmbeddedEntity("OwnedItem", data, {
			renderSheet: true,
		});
	}

	async _charGen() {
		const chargen = await new ForbiddenLandsCharacterGenerator(
			await ForbiddenLandsCharacterGenerator.loadDataset(),
			this.actor,
		);
		return chargen.render(true);
	}

	_getHeaderButtons() {
		let buttons = super._getHeaderButtons();

		if (this.actor.owner) {
			buttons = [
				{
					label: game.i18n.localize("SHEET.HEADER.ROLL"),
					class: "custom-roll",
					icon: "fas fa-dice",
					onclick: () => RollDialog.prepareRollDialog("DICE.ROLL", 0, 0, 0, "", 0, 0, this.diceRoller, null),
				},
				{
					label: game.i18n.localize("SHEET.HEADER.PUSH"),
					class: "push-roll",
					icon: "fas fa-skull",
					onclick: () => this.diceRoller.push(this.diceRoller),
				},
				{
					label: game.i18n.localize("SHEET.HEADER.CHAR_GEN"),
					class: "char-gen",
					icon: "fas fa-leaf",
					onclick: async () => {
						const hasFilledAttributes = Object.values(this.actor.data.data.attribute)
							.flatMap((a) => a.value + a.max)
							.some((v) => v > 0);

						if (hasFilledAttributes) {
							Dialog.confirm({
								title: game.i18n.localize("FLCG.TITLE"),
								content: `
									<h1 style="text-align: center;font-weight: 600; border:none;">${game.i18n.localize("FLCG.WARNING")}</h1>
									<p>${game.i18n.localize("FLCG.WARNING_DESTRUCTIVE_EDIT")}</p><hr/>
									<p>${game.i18n.localize("FLCG.WARNING_HINT")}</p>
									<p style="text-align: center;"><b>${game.i18n.localize("FLCG.WARNING_ARE_YOU_SURE")}</b></p>
									<br/>`,
								yes: async () => await this._charGen(),
								no: () => {},
							});
						} else {
							await this._charGen();
						}
					},
				},
			].concat(buttons);
		}

		return buttons;
	}
}

class ForbiddenLandsMonsterSheet extends ForbiddenLandsActorSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			classes: ["forbidden-lands", "sheet", "actor"],
			template: "systems/forbidden-lands/templates/monster.hbs",
			width: 700,
			height: 770,
			resizable: false,
			scrollY: [
				".monster-talents .item-list .items",
				".monster-attacks .item-list .items",
				".gears.item-list .items",
			],
			tabs: [
				{
					navSelector: ".sheet-tabs",
					contentSelector: ".sheet-body",
					initial: "main",
				},
			],
		});
	}

	getData() {
		const data = super.getData();
		this.computeSkills(data);
		this.computeItems(data);
		this.computeEncumbrance(data);
		return data;
	}

	activateListeners(html) {
		super.activateListeners(html);
		html.find(".item-create").click((ev) => {
			this.onItemCreate(ev);
		});
		html.find(".roll-armor").click(() => {
			let armorValue = this.actor.data.data.armor.value;
			RollDialog.prepareRollDialog("HEADER.ARMOR", 0, 0, armorValue, "", 0, 0, this.diceRoller, null);
		});
		html.find(".roll-attack").click((ev) => {
			const itemId = $(ev.currentTarget).data("itemId");
			const weapon = this.actor.getOwnedItem(itemId);
			let testName = weapon.name;
			RollDialog.prepareRollDialog(
				testName,
				weapon.data.data.dice,
				0,
				0,
				"",
				0,
				weapon.data.data.damage,
				this.diceRoller,
				null,
			);
		});
		html.find(".change-mounted").click(() => {
			const boolean = this.actor.data.data.isMounted;
			this.actor.update({ "data.isMounted": !boolean });
		});
	}

	computeEncumbrance(data) {
		let weightCarried = 0;
		for (let item of Object.values(data.items)) {
			weightCarried += this.computerItemEncumbrance(item);
		}
		const weightAllowed = data.data.attribute.strength.max * 2 * (data.data.isMounted ? 1 : 2);
		data.data.encumbrance = {
			value: weightCarried,
			max: weightAllowed,
			over: weightCarried > weightAllowed,
		};
	}

	computeSkills(data) {
		for (let skill of Object.values(data.data.skill)) {
			skill.hasStrength = skill.attribute === "strength";
			skill.hasAgility = skill.attribute === "agility";
			skill.hasWits = skill.attribute === "wits";
			skill.hasEmpathy = skill.attribute === "empathy";
		}
	}

	computeItems(data) {
		for (let item of Object.values(data.items)) {
			item.isMonsterAttack = item.type === "monsterAttack";
			item.isMonsterTalent = item.type === "monsterTalent";
			item.isWeapon = item.type === "weapon";
			item.isArmor = item.type === "armor";
			item.isGear = item.type === "gear";
			item.isRawMaterial = item.type === "rawMaterial";
		}
	}

	onItemCreate(event) {
		event.preventDefault();
		let header = event.currentTarget;
		let data = duplicate(header.dataset);
		data.name = `New ${data.type.capitalize()}`;
		this.actor.createEmbeddedEntity("OwnedItem", data, { renderSheet: true });
	}

	_getHeaderButtons() {
		let buttons = super._getHeaderButtons();

		if (this.actor.owner) {
			buttons = [
				{
					label: game.i18n.localize("SHEET.HEADER.ROLL"),
					class: "custom-roll",
					icon: "fas fa-dice",
					onclick: () => RollDialog.prepareRollDialog("DICE.ROLL", 0, 0, 0, "", 0, 0, this.diceRoller, null),
				},
			].concat(buttons);
		}

		return buttons;
	}
}

class ForbiddenLandsStrongholdSheet extends ForbiddenLandsActorSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			classes: ["forbidden-lands", "sheet", "actor"],
			template: "systems/forbidden-lands/templates/stronghold.hbs",
			width: 650,
			height: 700,
			resizable: false,
			scrollY: [".buildings.item-list .items", ".hirelings.item-list .items", ".gears.item-list .items"],
			tabs: [
				{
					navSelector: ".sheet-tabs",
					contentSelector: ".sheet-body",
					initial: "building",
				},
			],
		});
	}

	getData() {
		const data = super.getData();
		this._computeItems(data);
		return data;
	}

	activateListeners(html) {
		super.activateListeners(html);
		html.find(".item-create").click((ev) => {
			this.onItemCreate(ev);
		});
	}

	_computeItems(data) {
		for (let item of Object.values(data.items)) {
			item.isWeapon = item.type === "weapon";
			item.isArmor = item.type === "armor";
			item.isGear = item.type === "gear";
			item.isRawMaterial = item.type === "rawMaterial";
			item.isBuilding = item.type === "building";
			item.isHireling = item.type === "hireling";
			if (item.type !== "building" || item.type !== "hireling") {
				item.totalWeight =
					(game.fbl.config.encumbrance[item.data.weight] ?? item.data.weight ?? 1) *
					(item.data.quantity ?? 1);
			}
		}
	}

	onItemCreate(event) {
		event.preventDefault();
		let header = event.currentTarget;
		let data = duplicate(header.dataset);
		data.name = `New ${data.type.capitalize()}`;
		this.actor.createEmbeddedEntity("OwnedItem", data, { renderSheet: true });
	}
}

class CharacterPickerDialog extends Dialog {
	/**
	 * Show dialog that allows to pick a character from a list
	 *
	 */
	static async show(title, characters = [], onSelect, onCancel) {
		onSelect = onSelect || function () {};
		onCancel = onCancel || function () {};

		const characterSelector = await this.buildCharacterSelector(characters);

		let d = new CharacterPickerDialog({
			title: title,
			content: this.buildDivHtmlDialog(characterSelector),
			buttons: {
				cancel: {
					icon: '<i class="fas fa-times"></i>',
					label: "Cancel",
					callback: onCancel,
				},
			},
			select: onSelect,
			default: "cancel",
			close: onCancel,
		});
		d.render(true);
	}

	/**
	 * @param  {string} html Dialog content
	 */
	activateListeners(html) {
		super.activateListeners(html);
		html.find(".party-member").click(this.handleCharacterSelect.bind(this));
	}

	handleCharacterSelect(event) {
		this.data.select($(event.currentTarget).data("entity-id"));
		this.close();
	}

	/**
	 * @param  {Array} characters Array with character IDs
	 */
	static async buildCharacterSelector(characters) {
		let html = "";
		let actor;
		for (let i = 0; i < characters.length; i++) {
			actor = characters[i] instanceof Actor ? characters[i].data : game.actors.get(characters[i]).data;
			html += await renderTemplate("systems/forbidden-lands/templates/partial/party-member.hbs", {
				partyMember: actor,
				noCharSheetLink: true,
			});
		}
		return `<ol>${html}</ol>`;
	}

	/**
	 * @param  {string} divContent
	 */
	static buildDivHtmlDialog(divContent) {
		return "<div class='flex row roll-dialog'>" + divContent + "</div>";
	}
}

class InfoDialog {
	/**
	 * Display informational message.
	 *
	 * @param  {string}   title
	 * @param  {string}   message
	 * @param  {Function} onClose
	 */
	static show(title, message, onClose) {
		let d = new Dialog({
			title: title,
			content: this.buildDivHtmlDialog(message),
			buttons: {
				ok: {
					icon: '<i class="fas fa-check"></i>',
					label: "OK",
					callback: onClose,
				},
			},
			default: "ok",
			close: onClose,
		});
		d.render(true);
	}

	/**
	 * @param  {string} divContent
	 */
	static buildDivHtmlDialog(divContent) {
		return "<div class='flex row roll-dialog'>" + divContent + "</div>";
	}
}

class Helpers {
	static getCharacterDiceRoller(character) {
		character = character instanceof Actor ? character : game.user.character;
		if (!character) return;

		let charSheetClass = function () {};
		for (let name in CONFIG.Actor.sheetClasses.character) {
			if (name === "forbidden-lands.ForbiddenLandsCharacterSheet") {
				charSheetClass = CONFIG.Actor.sheetClasses.character[name].cls;
				break;
			}
		}
		let charSheet;
		for (let key in character.apps) {
			if (character.apps[key] instanceof charSheetClass) {
				charSheet = character.apps[key];
				break;
			}
		}
		if (!charSheet) {
			InfoDialog.show(game.i18n.localize("FLPS.UI.ATTENTION"), game.i18n.localize("FLPS.UI.ERROR.OPEN_SHEET"));
			return null;
		}

		return charSheet.diceRoller;
	}

	static getOwnedCharacters(characterIds) {
		characterIds = typeof characterIds !== "object" && characterIds !== "" ? [characterIds] : characterIds;
		let characters = [];
		for (let i = 0; i < characterIds.length; i++) {
			characters.push(game.actors.get(characterIds[i]));
		}
		characters = characters.filter((character) => character.owner);

		return characters;
	}
}

/**
 * Roll skill check to perform a travel action
 *
 * @param  {string}   rollName    Display name for the roll
 * @param  {string}   skillName   Unlocalized label
 * @param  {Function} onAfterRoll Callback that will be executed after roll is made
 */
function doRollTravelAction(character, rollName, skillName, onAfterRoll) {
	if (!character && game.user.character === null) return;

	character = character || game.user.character;
	const diceRoller = Helpers.getCharacterDiceRoller(character);
	if (diceRoller === null) return;

	const data = character.data.data;
	const skill = data.skill[skillName];

	RollDialog.prepareRollDialog(
		game.i18n.localize(rollName),
		{
			name: game.i18n.localize(data.attribute[skill.attribute].label),
			value: data.attribute[skill.attribute].value,
		},
		{ name: game.i18n.localize(skill.label), value: skill.value },
		0,
		"",
		0,
		0,
		diceRoller,
		onAfterRoll,
	);
}

/**
 * Roll skill check to perform a travel action
 *
 * @param  {Array}   assignedPartyMemberIds
 * @param  {string}   rollName             Display name for the roll
 * @param  {string}   skillName            Unlocalized label
 * @param  {Function} onAfterRoll          Callback that will be executed after roll is made
 */
function rollTravelAction(assignedPartyMemberIds, rollName, skillName, doRoll, onAfterRoll) {
	let assignedPartyMembers = Helpers.getOwnedCharacters(assignedPartyMemberIds);

	if (assignedPartyMembers.length === 1) {
		doRoll(assignedPartyMembers[0], rollName, skillName, onAfterRoll);
	} else if (assignedPartyMembers.length > 1) {
		CharacterPickerDialog.show(
			game.i18n.localize("FLPS.UI.WHO_ROLLS") + " " + game.i18n.localize(rollName),
			assignedPartyMembers,
			function (entityId) {
				doRoll(game.actors.get(entityId), rollName, skillName, onAfterRoll);
			},
		);
	}
}

let TravelActionsConfig = {
	hike: {
		key: "hike",
		journalEntryName: "Hike",
		name: "FLPS.TRAVEL.HIKE",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.FORCED_MARCH",
				class: "travel-forced-march",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.hike,
						"FLPS.TRAVEL_ROLL.FORCED_MARCH",
						"endurance",
						doRollTravelAction,
					);
				},
			},
			{
				name: "FLPS.TRAVEL_ROLL.HIKE_IN_DARKNESS",
				class: "travel-hike-in-darkness",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.hike,
						"FLPS.TRAVEL_ROLL.HIKE_IN_DARKNESS",
						"scouting",
						doRollTravelAction,
					);
				},
			},
		],
	},
	lead: {
		key: "lead",
		journalEntryName: "Lead the Way",
		name: "FLPS.TRAVEL.LEAD",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.NAVIGATE",
				class: "travel-navigate",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.lead,
						"FLPS.TRAVEL_ROLL.NAVIGATE",
						"survival",
						doRollTravelAction,
					);
				},
			},
		],
	},
	watch: {
		key: "watch",
		journalEntryName: "Keep Watch",
		name: "FLPS.TRAVEL.WATCH",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.KEEP_WATCH",
				class: "travel-keep-watch",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.watch,
						"FLPS.TRAVEL_ROLL.KEEP_WATCH",
						"scouting",
						doRollTravelAction,
					);
				},
			},
		],
	},
	rest: {
		key: "rest",
		journalEntryName: "Rest",
		name: "FLPS.TRAVEL.REST",
		buttons: [],
	},
	sleep: {
		key: "sleep",
		journalEntryName: "Sleep",
		name: "FLPS.TRAVEL.SLEEP",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.FIND_GOOD_PLACE",
				class: "travel-find-good-place",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.sleep,
						"FLPS.TRAVEL_ROLL.FIND_GOOD_PLACE",
						"survival",
						doRollTravelAction,
					);
				},
			},
		],
	},
	forage: {
		key: "forage",
		journalEntryName: "Forage",
		name: "FLPS.TRAVEL.FORAGE",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.FIND_FOOD",
				class: "travel-find-food",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.forage,
						"FLPS.TRAVEL_ROLL.FIND_FOOD",
						"survival",
						doRollTravelAction,
					);
				},
			},
		],
	},
	hunt: {
		key: "hunt",
		journalEntryName: "Hunt",
		name: "FLPS.TRAVEL.HUNT",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.FIND_PREY",
				class: "travel-find-prey",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.hunt,
						"FLPS.TRAVEL_ROLL.FIND_PREY",
						"survival",
						doRollTravelAction,
						function (diceRoller) {
							// onAfterRoll
							const isSuccess = diceRoller.countSword() > 0;
							if (isSuccess) {
								let rolltable = game.tables.getName("Find a Prey");
								if (rolltable) {
									rolltable.draw();
								} else {
									let chatData = {
										user: game.user._id,
										content:
											"You've spotted a prey!<br><i>Create a roll table named 'Find a Prey' to automatically find out what creature have you spotted.<i>",
									};
									ChatMessage.create(chatData, {});
								}
							}
						},
					);
				},
			},
			{
				name: "FLPS.TRAVEL_ROLL.KILL_PREY",
				class: "travel-kill-prey",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.hunt,
						"FLPS.TRAVEL_ROLL.KILL_PREY",
						"survival",
						function (character, rollName, _skillName, onAfterRoll) {
							if (!character && game.user.character === null) return;
							character = character || game.user.character;
							const diceRoller = Helpers.getCharacterDiceRoller(character);
							if (diceRoller === null) return;

							const data = character.data.data;
							const skill = data.skill.marksmanship;

							RollDialog.prepareRollDialog(
								game.i18n.localize(rollName),
								data.attribute[skill.attribute].value,
								skill.value,
								0,
								"",
								0,
								0,
								diceRoller,
								onAfterRoll,
							);
						},
					);
				},
			},
		],
	},
	fish: {
		key: "fish",
		journalEntryName: "Fish",
		name: "FLPS.TRAVEL.FISH",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.CATCH_FISH",
				class: "travel-catch-fish",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.fish,
						"FLPS.TRAVEL_ROLL.CATCH_FISH",
						"survival",
						doRollTravelAction,
					);
				},
			},
		],
	},
	camp: {
		key: "camp",
		journalEntryName: "Make Camp",
		name: "FLPS.TRAVEL.CAMP",
		buttons: [
			{
				name: "FLPS.TRAVEL_ROLL.MAKE_CAMP",
				class: "travel-make-camp",
				handler: function (party) {
					rollTravelAction(
						party.actor.data.data.travel.camp,
						"FLPS.TRAVEL_ROLL.MAKE_CAMP",
						"survival",
						doRollTravelAction,
					);
				},
			},
		],
	},
	other: {
		key: "other",
		journalEntryName: "",
		name: "FLPS.TRAVEL.OTHER",
		buttons: [],
	},
};

class ForbiddenLandsPartySheet extends ActorSheet {
	static get defaultOptions() {
		let dragDrop = [...super.defaultOptions.dragDrop];
		dragDrop.push({ dragSelector: ".party-member", dropSelector: ".party-member-list" });
		return mergeObject(super.defaultOptions, {
			classes: ["forbidden-lands", "sheet", "actor", "party"],
			template: "systems/forbidden-lands/templates/party.hbs",
			width: window.innerWidth * 0.05 + 650,
			resizable: false,
			tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "main" }],
			dragDrop: dragDrop,
		});
	}

	getData() {
		const data = super.getData();
		data.partyMembers = {};
		data.travel = {};
		data.travelActions = this.getTravelActions();
		let ownedActorId, assignedActorId, travelAction;
		for (let i = 0; i < (data.actor.data.members || []).length; i++) {
			ownedActorId = data.actor.data.members[i];
			data.partyMembers[ownedActorId] = game.actors.get(ownedActorId).data;
		}
		for (let travelActionKey in data.actor.data.travel) {
			travelAction = data.actor.data.travel[travelActionKey];
			data.travel[travelActionKey] = {};

			if (typeof travelAction === "object") {
				for (let i = 0; i < travelAction.length; i++) {
					assignedActorId = travelAction[i];
					data.travel[travelActionKey][assignedActorId] = game.actors.get(assignedActorId).data;
				}
			} else if (travelAction !== "") {
				data.travel[travelActionKey][travelAction] = game.actors.get(travelAction).data;
			}
		}
		return data;
	}

	activateListeners(html) {
		super.activateListeners(html);

		html.find(".item-delete").click(this.handleRemoveMember.bind(this));
		html.find(".reset").click(() => {
			this.assignPartyMembersToAction(this.actor.data.data.members, "other");
			this.render(true);
		});

		let button;
		for (let key in TravelActionsConfig) {
			for (let i = 0; i < TravelActionsConfig[key].buttons.length; i++) {
				button = TravelActionsConfig[key].buttons[i];
				html.find("." + button.class).click(button.handler.bind(this, this));
			}
		}
	}

	_getHeaderButtons() {
		let buttons = super._getHeaderButtons();

		if (this.actor.owner) {
			buttons = [
				{
					label: "Push",
					class: "push-roll",
					icon: "fas fa-skull",
					onclick: () => {
						let ownedPartyMembers = Helpers.getOwnedCharacters(this.actor.data.data.members);
						let diceRoller;

						if (ownedPartyMembers.length === 1) {
							diceRoller = Helpers.getCharacterDiceRoller(ownedPartyMembers[0]);
							if (!diceRoller) return;
							diceRoller.push();
						} else if (ownedPartyMembers.length > 1) {
							CharacterPickerDialog.show(
								game.i18n.localize("FLPS.UI.WHO_PUSHES"),
								ownedPartyMembers,
								function (entityId) {
									diceRoller = Helpers.getCharacterDiceRoller(game.actors.get(entityId));
									if (!diceRoller) return;
									diceRoller.push();
								},
							);
						}
					},
				},
			].concat(buttons);
		}

		return buttons;
	}

	getTravelActions() {
		let travelActions = TravelActionsConfig;
		for (const action of Object.values(travelActions)) {
			action.displayJournalEntry =
				action.journalEntryName && game.journal.getName(action.journalEntryName) !== null;
		}
		return travelActions;
	}

	async handleRemoveMember(event) {
		const div = $(event.currentTarget).parents(".party-member");
		const entityId = div.data("entity-id");

		let partyMembers = this.actor.data.data.members;
		partyMembers.splice(partyMembers.indexOf(entityId), 1);

		let updateData = {
			"data.members": partyMembers,
		};

		let travelAction, actionParticipants;
		for (let travelActionKey in this.actor.data.data.travel) {
			travelAction = this.actor.data.data.travel[travelActionKey];
			if (travelAction.indexOf(entityId) < 0) continue;

			if (typeof travelAction === "object") {
				actionParticipants = [...travelAction];
				actionParticipants.splice(actionParticipants.indexOf(entityId), 1);
				updateData["data.travel." + travelActionKey] = actionParticipants;
			} else {
				updateData["data.travel." + travelActionKey] = "";
			}
		}

		await this.actor.update(updateData);

		div.slideUp(200, () => this.render(false));
	}

	_onDragStart(event) {
		if (event.currentTarget.dataset.itemId !== undefined) {
			super._onDragStart(event);
			return;
		}

		let entityId = event.currentTarget.dataset.entityId;
		event.dataTransfer.setData(
			"text/plain",
			JSON.stringify({
				type: "Actor",
				action: "assign",
				id: entityId,
			}),
		);
	}

	async _onDrop(event) {
		super._onDrop(event);

		const json = event.dataTransfer.getData("text/plain");
		if (!json) return;

		let draggedItem = JSON.parse(json);
		if (draggedItem.type !== "Actor") return;

		const actor = game.actors.get(draggedItem.id);
		if (actor.data.type !== "character") return;

		if (draggedItem.action === "assign") {
			this.handleTravelActionAssignment(event, actor);
		} else {
			this.handleAddToParty(actor);
		}
		this.render(true);
	}

	async handleTravelActionAssignment(event, actor) {
		const targetElement = event.toElement ? event.toElement : event.target;
		let actionContainer = targetElement.classList.contains("travel-action")
			? targetElement
			: targetElement.closest(".travel-action");
		if (actionContainer === null) return; // character was dragged god knows where; just pretend it never happened

		this.assignPartyMembersToAction(actor, actionContainer.dataset.travelAction);
	}

	async assignPartyMembersToAction(partyMembers, travelActionKey) {
		if (!Array.isArray(partyMembers)) partyMembers = [partyMembers];

		let updateData = {},
			updDataKey,
			partyMemberId;
		for (let i = 0; i < partyMembers.length; i++) {
			partyMemberId = typeof partyMembers[i] === "object" ? partyMembers[i].data._id : partyMembers[i];

			// remove party member from the current assignment
			let travelAction, actionParticipants;
			for (let key in this.actor.data.data.travel) {
				travelAction = this.actor.data.data.travel[key];
				if (travelAction.indexOf(partyMemberId) < 0) continue;

				updDataKey = "data.travel." + key;
				if (typeof travelAction === "object") {
					if (updateData[updDataKey] === undefined) {
						actionParticipants = [...travelAction];
						actionParticipants.splice(actionParticipants.indexOf(partyMemberId), 1);
						updateData[updDataKey] = actionParticipants;
					} else {
						updateData[updDataKey].splice(updateData[updDataKey].indexOf(partyMemberId), 1);
					}
				} else {
					updateData[updDataKey] = "";
				}
			}

			// add party member to a new assignment
			updDataKey = "data.travel." + travelActionKey;
			if (typeof this.actor.data.data.travel[travelActionKey] === "object") {
				if (updateData[updDataKey] === undefined) {
					actionParticipants = [...this.actor.data.data.travel[travelActionKey]];
					actionParticipants.push(partyMemberId);
					updateData[updDataKey] = actionParticipants;
				} else {
					updateData[updDataKey].push(partyMemberId);
				}
			} else {
				updateData[updDataKey] = partyMemberId;
				// if someone was already assigned here we must move that character to the "Other" assignment
				if (this.actor.data.data.travel[travelActionKey] !== "") {
					if (updateData["data.travel.other"] === undefined) {
						actionParticipants = [...this.actor.data.data.travel.other];
						actionParticipants.push(this.actor.data.data.travel[travelActionKey]);
						updateData["data.travel.other"] = actionParticipants;
					} else {
						updateData["data.travel.other"].push(this.actor.data.data.travel[travelActionKey]);
					}
				}
			}
		}

		await this.actor.update(updateData);
	}

	async handleAddToParty(actor) {
		let partyMembers = this.actor.data.data.members;
		let initialCount = partyMembers.length;
		partyMembers.push(actor.data._id);
		// eslint-disable-next-line no-undef
		partyMembers = [...new Set(partyMembers)]; // remove duplicate values
		if (initialCount === partyMembers.length) return; // nothing changed

		let travelOther = [...this.actor.data.data.travel.other];
		travelOther.push(actor.data._id);
		await this.actor.update({ "data.members": partyMembers, "data.travel.other": travelOther });
	}
}

class ForbiddenLandsItemSheet extends ItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			classes: ["forbidden-lands", "sheet", "item"],
			width: window.innerWidth * 0.18 + 150,
			resizable: false,
		});
	}

	_getHeaderButtons() {
		let buttons = super._getHeaderButtons();
		buttons = [
			{
				label: game.i18n.localize("SHEET.HEADER.POST_ITEM"),
				class: "item-post",
				icon: "fas fa-comment",
				onclick: () => {
					const item = this.item;
					item.sendToChat();
				},
			},
		].concat(buttons);
		return buttons;
	}

	_computeQuality(data) {
		data.artifact = !!data.data.artifactBonus;
		data.lethal = data.data.lethal === "yes";
		data.ranks = !data.data.type || data.data.type !== "kin";
	}

	getData() {
		const data = super.getData();
		this._computeQuality(data);
		return data;
	}

	_onChangeTab(event, tabs, active) {
		$(`#${this.id} textarea`).each(function () {
			if (this.value) {
				this.readOnly = true;
				this.setAttribute("style", "height:" + this.scrollHeight + "px;overflow-y:hidden;");
			}
		});
		return super._onChangeTab(event, tabs, active);
	}

	activateListeners(html) {
		super.activateListeners(html);
		html.find(".add-modifier").click(async (ev) => {
			ev.preventDefault();
			let data = this.getData();
			let rollModifiers = data.data.rollModifiers || {};
			// To preserve order, make sure the new index is the highest
			let modifierId = Math.max(-1, ...Object.getOwnPropertyNames(rollModifiers)) + 1;
			let update = {};
			update[`data.rollModifiers.${modifierId}`] = {
				name: "",
				value: "",
			};
			await this.item.update(update);
		});
		html.find(".delete-modifier").click(async (ev) => {
			ev.preventDefault();
			let data = this.getData();
			let rollModifiers = duplicate(data.data.rollModifiers || {});
			let modifierId = $(ev.currentTarget).data("modifier-id");
			delete rollModifiers[modifierId];
			// Safety cleanup of null modifiers
			for (let key in Object.keys(rollModifiers)) {
				if (!rollModifiers[key]) {
					delete rollModifiers[key];
				}
			}
			// There seems to be some issue replacing an existing object, if we set
			// it to null first it works better.
			await this.item.update({ "data.rollModifiers": null });
			if (Object.keys(rollModifiers).length > 0) {
				await this.item.update({ "data.rollModifiers": rollModifiers });
			}
		});
		html.find(".change-bonus").on("click contextmenu", (ev) => {
			const bonus = this.object.data.data.bonus;
			let value = bonus.value;
			const altInteraction = game.settings.get("forbidden-lands", "alternativeSkulls");
			if ((ev.type === "click" && !altInteraction) || (ev.type === "contextmenu" && altInteraction)) {
				value = Math.max(value - 1, 0);
			} else if ((ev.type === "contextmenu" && !altInteraction) || (ev.type === "click" && altInteraction)) {
				value = Math.min(value + 1, bonus.max);
			}
			this.object.update({
				["data.bonus.value"]: value,
			});
		});
		html.find(".feature").click(async (ev) => {
			const featureName = $(ev.currentTarget).data("feature");
			const features = this.object.data.data.features;
			if (game.fbl.config.weaponFeatures.includes(featureName))
				this.object.update({ [`data.features.${featureName}`]: !features[featureName] });
			this._render();
		});
		html.find("textarea").on("input blur contextmenu dblclick mouseover mouseout", (ev) => {
			if (game.user.isGM || this.object.isOwned) {
				const element = ev.currentTarget;
				const legend = document.createElement("legend");
				legend.classList.add("legend");
				legend.innerText = game.i18n.localize("SHEET.TEXTAREA_EDIT");
				switch (ev.type) {
					case "mouseover":
						if (element.readOnly) {
							element.after(legend);
							setTimeout(() => (legend.style.opacity = "1"), 100);
						}
						break;
					case "mouseout":
						$("textarea ~ legend").remove();
						break;
					case "input":
						element.style.height = element.scrollHeight + "px";
						break;
					case "blur":
						element.readOnly = true;
						break;
					case "contextmenu":
					case "dblclick":
						element.readOnly = false;
						$("textarea ~ legend").remove();
						break;
				}
			}
		});
	}

	async getCustomRollModifiers() {
		let pack = game.packs.get("world.customrollmodifiers");
		if (pack) {
			let customRollModifier = await pack.getContent();
			return customRollModifier.map((item) => item.name);
		}
		return [];
	}

	async _renderInner(data, options) {
		data = {
			...data,
			alternativeSkulls: game.settings.get("forbidden-lands", "alternativeSkulls"),
			showCraftingFields: game.settings.get("forbidden-lands", "showCraftingFields"),
			showCostField: game.settings.get("forbidden-lands", "showCostField"),
			showSupplyField: game.settings.get("forbidden-lands", "showSupplyField"),
			showEffectField: game.settings.get("forbidden-lands", "showEffectField"),
			showDescriptionField: game.settings.get("forbidden-lands", "showDescriptionField"),
			showDrawbackField: game.settings.get("forbidden-lands", "showDrawbackField"),
			showAppearanceField: game.settings.get("forbidden-lands", "showAppearanceField"),
		};
		data.data.customRollModifiers = await this.getCustomRollModifiers();
		return super._renderInner(data, options);
	}
}

class ForbiddenLandsWeaponSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/weapon.hbs",
			tabs: [
				{
					navSelector: ".sheet-tabs",
					contentSelector: ".sheet-body",
					initial: "main",
				},
			],
		});
	}
}

class ForbiddenLandsArmorSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/armor.hbs",
			tabs: [
				{
					navSelector: ".sheet-tabs",
					contentSelector: ".sheet-body",
					initial: "main",
				},
			],
		});
	}
}

class ForbiddenLandsGearSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/gear.hbs",
			tabs: [
				{
					navSelector: ".sheet-tabs",
					contentSelector: ".sheet-body",
					initial: "main",
				},
			],
		});
	}
}

class ForbiddenLandsRawMaterialSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/raw-material.hbs",
		});
	}
}

class ForbiddenLandsSpellSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/spell.hbs",
		});
	}
}

class ForbiddenLandsTalentSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/talent.hbs",
		});
	}
}

class ForbiddenLandsCriticalInjurySheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/critical-injury.hbs",
			width: 400,
			height: 310,
		});
	}
}

class ForbiddenLandsMonsterTalentSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/monster-talent.hbs",
		});
	}
}

class ForbiddenLandsMonsterAttackSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/monster-attack.hbs",
		});
	}
}

class ForbiddenLandsBuildingSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/building.hbs",
		});
	}
}

class ForbiddenLandsHirelingSheet extends ForbiddenLandsItemSheet {
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			...super.defaultOptions,
			template: "systems/forbidden-lands/templates/hireling.hbs",
		});
	}
}

function registerSheets() {
	Actors.unregisterSheet("core", ActorSheet);
	Actors.registerSheet("forbidden-lands", ForbiddenLandsCharacterSheet, { types: ["character"], makeDefault: true });
	Actors.registerSheet("forbidden-lands", ForbiddenLandsMonsterSheet, { types: ["monster"], makeDefault: true });
	Actors.registerSheet("forbidden-lands", ForbiddenLandsStrongholdSheet, {
		types: ["stronghold"],
		makeDefault: true,
	});
	Actors.registerSheet("forbidden-lands", ForbiddenLandsPartySheet, { types: ["party"], makeDefault: true });
	Items.unregisterSheet("core", ItemSheet);
	Items.registerSheet("forbidden-lands", ForbiddenLandsWeaponSheet, { types: ["weapon"], makeDefault: true });
	Items.registerSheet("forbidden-lands", ForbiddenLandsArmorSheet, { types: ["armor"], makeDefault: true });
	Items.registerSheet("forbidden-lands", ForbiddenLandsGearSheet, { types: ["gear"], makeDefault: true });
	Items.registerSheet("forbidden-lands", ForbiddenLandsRawMaterialSheet, {
		types: ["rawMaterial"],
		makeDefault: true,
	});
	Items.registerSheet("forbidden-lands", ForbiddenLandsSpellSheet, { types: ["spell"], makeDefault: true });
	Items.registerSheet("forbidden-lands", ForbiddenLandsTalentSheet, { types: ["talent"], makeDefault: true });
	Items.registerSheet("forbidden-lands", ForbiddenLandsCriticalInjurySheet, {
		types: ["criticalInjury"],
		makeDefault: true,
	});
	Items.registerSheet("forbidden-lands", ForbiddenLandsMonsterTalentSheet, {
		types: ["monsterTalent"],
		makeDefault: true,
	});
	Items.registerSheet("forbidden-lands", ForbiddenLandsMonsterAttackSheet, {
		types: ["monsterAttack"],
		makeDefault: true,
	});
	Items.registerSheet("forbidden-lands", ForbiddenLandsBuildingSheet, { types: ["building"], makeDefault: true });
	Items.registerSheet("forbidden-lands", ForbiddenLandsHirelingSheet, { types: ["hireling"], makeDefault: true });
}

/**
 * @description This acts as a configuration utility for the system. Everything that doesn't need to go in template.json, but is still referenced throughout the system is gathered here.
 */

const FBL = {};

FBL.attributes = ["agility", "empathy", "strength", "wits"];

FBL.conditions = ["cold", "hungry", "sleepy", "thirsty"];

FBL.encumbrance = {
	tiny: 0,
	none: 0,
	light: 0.5,
	regular: 1,
	heavy: 2,
};

FBL.itemTypes = [
	"armor",
	"building",
	"criticalInjury",
	"gear",
	"hireling",
	"monsterAttack",
	"monsterTalent",
	"rawMaterial",
	"spell",
	"talent",
	"weapon",
];

FBL.weaponFeatures = ["blunt", "edged", "hook", "parrying", "pointed", "slowReload"];

function registerSettings() {
	game.settings.register("forbidden-lands", "worldSchemaVersion", {
		name: "World Version",
		hint: "Used to automatically upgrade worlds data when the system is upgraded.",
		scope: "world",
		config: false,
		default: 0,
		type: Number,
	});
	game.settings.register("forbidden-lands", "allowUnlimitedPush", {
		name: game.i18n.localize("FLPS.SETTINGS.ALLOW_PUSH"),
		hint: game.i18n.localize("FLPS.SETTINGS.ALLOW_PUSH_HINT"),
		scope: "world",
		config: true,
		default: false,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "alternativeSkulls", {
		name: "CONFIG.ALTERNATIVESKULLS",
		hint: "CONFIG.ALTERNATIVESKULLS_DESC",
		scope: "client",
		config: true,
		default: false,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "datasetDir", {
		name: game.i18n.localize("FLCG.SETTINGS.DATASET_DIR"),
		hint: game.i18n.localize("FLCG.SETTINGS.DATASET_DIR_HINT"),
		scope: "world",
		config: true,
		default: "systems/forbidden-lands/assets",
		type: window.Azzu.SettingsTypes.DirectoryPicker,
	});
	game.settings.register("forbidden-lands", "showCraftingFields", {
		name: "CONFIG.CRAFTINGFIELD",
		hint: "CONFIG.CRAFTINGFIELD_DESC",
		scope: "client",
		config: true,
		default: true,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "showCostField", {
		name: "CONFIG.COSTFIELD",
		hint: "CONFIG.COSTFIELD_DESC",
		scope: "client",
		config: true,
		default: true,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "showSupplyField", {
		name: "CONFIG.SUPPLYFIELD",
		hint: "CONFIG.SUPPLYFIELD_DESC",
		scope: "client",
		config: true,
		default: true,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "showEffectField", {
		name: "CONFIG.EFFECTFIELD",
		hint: "CONFIG.EFFECTFIELD_DESC",
		scope: "client",
		config: true,
		default: true,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "showDescriptionField", {
		name: "CONFIG.DESCRIPTIONFIELD",
		hint: "CONFIG.DESCRIPTIONFIELD_DESC",
		scope: "client",
		config: true,
		default: true,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "showDrawbackField", {
		name: "CONFIG.DRAWBACKFIELD",
		hint: "CONFIG.DRAWBACKFIELD_DESC",
		scope: "client",
		config: true,
		default: true,
		type: Boolean,
	});
	game.settings.register("forbidden-lands", "showAppearanceField", {
		name: "CONFIG.APPEARANCEFIELD",
		hint: "CONFIG.APPEARANCEFIELD_DESC",
		scope: "client",
		config: true,
		default: true,
		type: Boolean,
	});
}

CONFIG.debug.hooks = true;

Hooks.once("init", () => {
	game.fbl = {
		config: FBL,
	};
	CONFIG.Combat.initiative = { formula: "1d10", decimals: 0 };
	CONFIG.Actor.entityClass = ForbiddenLandsActor;
	CONFIG.Item.entityClass = ForbiddenLandsItem;
	CONFIG.rollDialog = RollDialog;
	CONFIG.diceRoller = new DiceRoller();
	registerFonts();
	registerSheets();
	registerDice();
	initializeHandlebars();
	registerSettings();
});

Hooks.once("ready", () => {
	migrateWorld();
	initializeCalendar();
});

Hooks.once("diceSoNiceReady", (dice3d) => {
	registerDiceSoNice(dice3d);
});

Hooks.on("renderItemSheet", function (app, html) {
	html.find("textarea").each(function () {
		if (this.value) {
			this.setAttribute("style", "height:" + this.scrollHeight + "px;overflow-y:hidden;");
			this.readOnly = true;
		}
	});
	app._element[0].style.height = "auto";
	html.find(".close").html(`<i class="fas fa-times"></i>` + game.i18n.localize("SHEET.CLOSE"));
	html.find(".configure-sheet").html(`<i class="fas fa-cog"></i>` + game.i18n.localize("SHEET.CONFIGURE"));
	html.find(".configure-token").html(`<i class="fas fa-user-circle"></i>` + game.i18n.localize("SHEET.TOKEN"));
});

Hooks.on("renderActorSheet", (app, html) => {
	if (app.actor.data.type === "party") app._element[0].style.height = "auto";
	html.find(".close").html(`<i class="fas fa-times"></i>` + game.i18n.localize("SHEET.CLOSE"));
	html.find(".configure-sheet").html(`<i class="fas fa-cog"></i>` + game.i18n.localize("SHEET.CONFIGURE"));
	html.find(".configure-token").html(`<i class="fas fa-user-circle"></i>` + game.i18n.localize("SHEET.TOKEN"));
});

Hooks.on("renderChatMessage", async (app, html) => {
	// Add drag and drop functonality to posted items
	let postedItem = html.find(".chat-item")[0];
	if (postedItem) {
		postedItem.classList.add("draggable");
		postedItem.setAttribute("draggable", true);
		postedItem.addEventListener("dragstart", (ev) => {
			ev.dataTransfer.setData(
				"text/plain",
				JSON.stringify({
					item: app.getFlag("forbidden-lands", "itemData"),
					type: "itemDrop",
				}),
			);
		});
	}
	// Push rolls
	const pushButton = html.find("button.push-roll");
	if (!app.roll) return;
	const rollData = app.data.flags["forbidden-lands"].rollData;
	const notPushable =
		app.data.flags["forbidden-lands"]?.pushed ||
		app.permission !== 3 ||
		!app.roll.dice.some((a) => a instanceof BaseDie || a instanceof GearDie) ||
		rollData.isSpell ||
		(rollData.isPushed && !game.settings.get("forbidden-lands", "allowUnlimitedPush")) ||
		(game.user.isGM && !game.settings.get("forbidden-lands", "allowUnlimitedPush"));
	if (notPushable) {
		pushButton.each((_i, b) => {
			b.style.display = "none";
		});
	} else {
		pushButton.on("click", () => {
			const diceRoller = new DiceRoller();
			diceRoller.push(rollData);
			app.update({ flags: { "forbidden-lands.pushed": true } });
		});
	}
});
