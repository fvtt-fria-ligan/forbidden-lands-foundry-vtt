# Forbidden Lands
An **OFFICIAL**, community managed system for playing Forbidden Lands on Foundry VTT.  
It provides support for **character sheets only**, game content should be drawn from official source books.

## Install
1. Go to the setup page and choose **Game Systems**.
2. Click the **Install System** button, and paste in this [manifest link](https://github.com/fvtt-fria-ligan/forbidden-lands-foundry-vtt/releases/latest/download/system.json)
3. Create a Game World using the Forbidden Lands system.

## Supported Modules
- [Calendar/Weather](https://foundryvtt.com/packages/calendar-weather/) will be configured with the correct calendar, support for seasons, dusk/dawn, and recurring events
- [Dice So Nice](https://foundryvtt.com/packages/dice-so-nice/) version 3.0 or later will give you beautiful 3D dice for each roll
- [Virtual Tabletop Assets - Tokenizer](https://foundryvtt.com/packages/vtta-tokenizer/) is supported on all character sheets

## Sneaky Preview
![Character Main](https://user-images.githubusercontent.com/9851733/104242530-95fdda00-545f-11eb-8077-f9ebb2bf1e49.png)  
![Character Combat](https://user-images.githubusercontent.com/9851733/104243355-b9755480-5460-11eb-8e59-c450e77dfb06.png)  
![Item Sheet](https://user-images.githubusercontent.com/9851733/104243408-ce51e800-5460-11eb-97ec-6a1afb76807c.png)  
![Item Chat](https://user-images.githubusercontent.com/9851733/104243430-d742b980-5460-11eb-956f-025188dbe91e.png)  

## To be done in the nearest future
A projects page will be initiated shortly. Keep an eye on the [Projects](https://github.com/fvtt-fria-ligan/forbidden-lands-foundry-vtt/projects) page.

## Related Website
- https://foundryvtt.com/
- https://frialigan.se/en/store/?collection_id=84541866032

## Side note
Buy this game. Seriously. Buy it.

## Credits
Dice graphics recreated by [Tomasz 'jarv' Dobrowolski](jarv@monochrome.pl) with permission from Fria Ligan.

## Licence
[GNU General Public License v3.0](https://choosealicense.com/licenses/gpl-3.0/)
