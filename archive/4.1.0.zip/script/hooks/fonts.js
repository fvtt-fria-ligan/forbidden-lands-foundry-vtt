export function registerFonts() {
  CONFIG.fontFamilies.push("IM Fell Great Primer");
  CONFIG.fontFamilies.push("IM Fell DW Pica");
  CONFIG.fontFamilies.push("IM Fell DW Pica SC");
  CONFIG.fontFamilies.push("Poppins");
  CONFIG.defaultFontFamily = "IM Fell DW Pica";
}
